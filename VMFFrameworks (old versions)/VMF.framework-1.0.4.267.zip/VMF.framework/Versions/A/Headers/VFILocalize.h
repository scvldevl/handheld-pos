//
//  VFILocalize.h
//  VMF
//
//  Created by Randy Palermo on 1/18/11.
//  Copyright 2011 VeriFone, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface VFILocalize : NSObject {

}

-(NSString*)localizeEnglishString:(NSString*)string lang:(int)lang;

@end
