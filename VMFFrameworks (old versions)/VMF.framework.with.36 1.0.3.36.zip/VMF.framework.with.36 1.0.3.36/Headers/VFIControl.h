


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import	<ExternalAccessory/ExternalAccessory.h>
#import "VFISoftwareVersion.h"
#import "VFIKeypadVersion.h"
#import "VFI_EADSessionController.h"


/** Protocol methods established for VFIControl class **/
@protocol VFIControlDelegate <NSObject>

@optional
- (void) controlLogEntry:(NSString*)logEntry withSeverity:(int)severity;
- (void) controlInitialized:(BOOL)isInitialized;

- (void) controlReconnectStarted;
- (void) controlReconnectFinished;
- (void) controlConnected:(BOOL)isConnected;
- (void) controlDataReceived:(NSData*)data;
- (void) controlDataSent:(NSData*)data;
@end

@class VFI_EADSessionController;

/**
 * API methods for Vx600 Pinpad Control.
 *
 * Implementing this class will allow access to API calls that will perform Vx600 Pinpad control, such as keypad beep on or off.
 */
@interface VFIControl : NSObject <VFI_EADSessionControllerDelegate, EAAccessoryDelegate, NSStreamDelegate,UIApplicationDelegate> {
	
	id <VFIControlDelegate> delegate;
	EAAccessory *_accessory;
	VFI_EADSessionController *_eaSessionController;
	VFISoftwareVersion *vfiSoftwareVersion;
	VFIKeypadVersion *vfiKeypadVersion;
	UIBackgroundTaskIdentifier bgTask;
}

-(id)init;
+ (VFIControl *)sharedController;
-(void) ignoreDisconnect;
-(void) initDevice:(NSNotification *)notification;
-(void) deviceDisconnected:(NSNotification *)notification;
-(void) deviceDisconnected2:(NSNotification *)notification;
-(void) deviceDisconnected3:(NSNotification *)notification;
-(void) initDevice;
-(void) initBridge;
-(void)deviceDisconnectedBridge:(NSNotification *)notification;
-(void) closeDevice;
-(void) sendCommand:(NSString*)cmd;
-(void) sendCommandLRC:(NSString*)cmd;
-(void) simulatorMode:(BOOL)activate;
-(void) keypadEnabled:(BOOL)isEnabled;
-(void) hostPowerEnabled:(BOOL)isEnabled;
-(void) keypadBeepEnabled:(BOOL)isEnabled;
-(void) powerDown;
-(void) queryBatteryLevel;
-(void) querySoftwareVersion;
-(void) queryKeypadVersion;
-(void) consoleEnabled:(BOOL)enable;
- (void)channelConnection:(NSString *)channelResponse;
-(void) setCommunicationID:(NSString *)commID;
-(id) initWithCommunicationID:(NSString *) commID;
-(NSString*) frameworkVersion;
-(NSString*) getLog;
-(NSString*) getLogFilename;
-(void) clearLog;
-(void) logEnabled:(BOOL)enable;
-(void) restartLoopDelay:(float)sec;
-(void)processReceivedData:(NSData*)data;
-(void)removeListeners;
-(void) setInitLoop:(int) loop;

@property (retain) id delegate;
@property (nonatomic, readonly) NSString *controlName;
@property (nonatomic, readonly) NSString *controlManufacturer;
@property (nonatomic, readonly) NSString *controlModelNumber;
@property (nonatomic, readonly) NSString *controlSerialNumber;
@property (nonatomic, readonly) NSString *controlFirmwareRevision;
@property (nonatomic, readonly) NSString *controlHardwareRevision;
@property (nonatomic, readonly) NSString *softwareVersion;
@property (nonatomic, readonly) NSString *keypadVersion;
@property (readonly) int batteryLevel;
@property (readonly) BOOL controlSimulatorMode;
@property (readonly) BOOL controlConnected;
@property (readonly) BOOL connected;
@property (readonly) BOOL BTconnected;
@property (nonatomic, retain) VFISoftwareVersion *vfiSoftwareVersion;
@property (nonatomic, retain) VFIKeypadVersion *vfiKeypadVersion;


@property (readonly) BOOL initialized;




@end

