//
//  VFIBTBridge.h
//  VMF
//
//  Created by Randy Palermo on 6/6/11.
//  Copyright 2011 VeriFone, Inc. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import	<ExternalAccessory/ExternalAccessory.h>
#import "VFIPinpad.h"
#import "VFIControl.h"
#import "VFIDebug.h"
#import "VFIZontalk.h"
#import "VFI_EADSessionController.h"


@protocol VFIBTBridgeDelegate <NSObject>

@optional

- (void) btbridgeDataReceived:(NSData*)data;
- (void) btbridgeDataSent:(NSData*)data;

@end



@class VFI_EADSessionControllery;


@interface VFIBTBridge : NSObject <EAAccessoryDelegate, NSStreamDelegate>{
	id <VFIBTBridgeDelegate> delegate;
	EAAccessory *_accessory;
	VFI_EADSessionControllery *_eaSessionController;
	NSMutableData *pinpadMD;
	NSMutableData *controlMD;
	NSMutableData *barcodeMD;
	NSMutableData *zontalkMD;
	NSMutableData *debugMD;
	UIBackgroundTaskIdentifier bgTask;
	
	
}
+(void) disableBTBridge;
+(BOOL) disabledBTBridge;
+(VFIBTBridge*) getBTBridge;
+(void) prepareOpenURL;
-(void) closeDevice;
-(void) setPinPadInit:(BOOL)init;
-(void) setBarcodeInit:(BOOL)init;
-(void) setControlInit:(BOOL)init;
-(void) setDebugInit:(BOOL)init;
-(void) setZontalkInit:(BOOL)init;
-(BOOL) initReady;
-(id)init;
-(void) setCommunicationID:(NSString *)commID;
-(id) initWithCommunicationID:(NSString *) commID;
-(void) initPinpad:(VFIPinpad*)del;
-(void) initZontalk:(VFIZontalk*)del;
-(void) initControl:(VFIControl*)del;
-(void) initDebug:(VFIDebug*)del;
-(void) initBarcode:(VFIBarcode*)del;
-(void) pinpadData:(NSData*)data;
-(void) controlData:(NSData*)data;
-(void) debugData:(NSData*)data;
-(void) barcodeData:(NSData*)data;
- (void)zontalkData:(NSData*)data;
- (void)sendString:(NSString*)string;
- (void)sendData:(NSData*)data;
-(void) sendDataToChannel:(NSData*)data channel:(int)channel;
-(void)deviceDisconnected:(NSNotification *)notification;
-(void)deviceDisconnected2:(NSNotification *)notification;
-(void) setPinPadDelegate:(VFIPinpad*)del;
-(void) setBarcodeDelegate:(VFIBarcode*)del;
-(void) setZontalkDelegate:(VFIZontalk*)del;
-(void) setControlDelegate:(VFIControl*)del;
-(void) setDebugDelegate:(VFIDebug*)del;
+(NSString *)Vx600Name;
+(NSString *)Vx600Manufacturer;
+(NSString *)Vx600ModelNumber;
+(NSString *)Vx600SerialNumber;
+(NSString *)Vx600FirmwareRevision;
+(NSString *)Vx600HardwareRevision;
+(NSString *)UDID;
-(void) setInitLoop:(int) loop;
@property (retain) id delegate;

@property (nonatomic, retain) NSMutableData *pinpadMD;
@property (nonatomic, retain) NSMutableData *controlMD;
@property (nonatomic, retain) NSMutableData *debugMD;
@property (nonatomic, retain) NSMutableData *barcodeMD;
@property (nonatomic, retain) NSMutableData *zontalkMD;
@property (readonly) BOOL connected;





@end
