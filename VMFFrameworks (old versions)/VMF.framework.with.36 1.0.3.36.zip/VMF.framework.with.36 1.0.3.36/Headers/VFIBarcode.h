

#import <Foundation/Foundation.h>
#import	<ExternalAccessory/ExternalAccessory.h>
#import "ISCP_HIGH.h"
#import <UIKit/UIKit.h>
#import "VFI_EADSessionController.h"

#define _barcodeFMVersion  @"1.0.0.13";


/** Single beep command defintions.
 Used in T_BEEP_DEF structure
 **/
typedef struct _T_BEEP {
    int freq; //!< Frequency of beep
    int dur; //!< Duration in milliseconds
}T_BEEP;

/** Beep Macro.
 Specify Beep1 and Beep2 frequency and duration. 
 Specify duration between Beep1 and Beep2. 
 For a single solid beep, set Beep1 frequency to 0 and Beep2 to
 desired frequency plus duration.
 Seting Beep1 and Beep2 frequency to <b>zero disables beep.</b>
 */
typedef struct _T_BEEP_DEF{
    T_BEEP b1; //!< Beep1
    int bPause; //!< Pause in milliseconds
    T_BEEP b2; //!< Beep2
}T_BEEP_DEF;

/** The frame type indicates what kind of frame is being sent or received. **/
enum  frameType{
 TYPE_SETUP_READ =0x40,             //!<The host sends a Setup Read to know how the scanner is configured.
 TYPE_SETUP_WRITE =0x41,            //!<The host sends a Setup Write to configure the scanner or modify the current configuration.
 TYPE_CONTROL =0x42,                //!< Control Command is used to control the scanner.
 TYPE_STATUS_READ =0x43,            //!< Status Read is used to find out information on the status of certain parameters in the scanner.
 TYPE_PERMISSION_READ =0x44,        //!< Setup Permission Read frame is used to find out what setup parameters can or cannot be changed by reading configuration bar codes.
 TYPE_PERMISSION_WRITE =0x45,       //!<Setup Permissions allow the host to prevent users from modifying the scanner's setup parameters when reading configuration bar codes.
 TYPE_SETUP_REPLY =0x50,            //!<A Setup Reply is used to send to the host information about the configuration of the scanner. This frame is sent in response to a Setup Read.
 TYPE_RESULT =0x51,                 //!<All Result frames, except Unknown Frame Type, are sent in response to three different kinds of frames: Setup Write, Control Command and Setup Permission Write.
 TYPE_STATUS_REPLY =0x53,           //!<After receiving a Status Read from the host, the scanner replies by sending the requested status parameter values to the host.
 TYPE_SETUP_PERMISSION_REPLY =0x54, //!<After receiving a Setup Permission Read from the host, the scanner replies by sending the permission status of the requested setup parameters.
 TYPE_BARCODE_DATA =0x60,           //!<A Barcode Data frame is a scanner-initiated frame. When the scanner reads a bar code, data is sent from the scanner to the host.
 TYPE_EVENT_NOTIFICATION =0x61,     //!<An Event notification is a scanner-initiated frame. It is used to inform the host when certain events have taken place such as an unsuccessful decoding, etc.
 TYPE_SETUP_BARCODE_DATA =0x62      //!<This frame is used to send configuration barcode data via the scanner to the host in packet format.
};



/**
 Barcode types.
 
 Values returned when option to identify returning barcode types is ON when VFIBarcode::barcodeTypeEnabled:() is passed <c>TRUE</c>.
 */
enum  barcodeTypes{
	BC_EAN_UPC2 ='X', 
	BC_EAN_UPC1 ='E', 
	BC_CODABAR ='F', 
	BC_CODABLOCK ='O', 
	BC_CODE11 ='H', 
	BC_CODE39 ='A', 
	BC_CODE93 ='G', 
	BC_CODE128 ='C', 
	BC_DATAMATRIX ='d', 
	BC_GS1 ='e', 
	BC_INTERLEAVED_2_OF_5 ='I', 
	BC_MAXICODE ='U', 
	BC_MSICODE ='M', 
	BC_PDF417 ='L', 
	BC_PLESSYCODE ='P', 
	BC_QRCODE ='Q', 
	BC_STAN_2_OF_5_2BARS ='R', 
	BC_STAN_2_OF_5_3BARS ='S', 
	BC_TELEPEN ='B'  
} ;



/** Scanning Modes **/
enum scanningModes{
    BCS_BUTTON_EDGE = 0,       //!< Scanning session begin on trigger press, and continues after trigger released.  Scanning completes upon successful scan capture, abortScan() or timeout.
    BCS_BUTTON_LEVEL,          //!< Scanning session begin on trigger press.  Scanning completes upon successful scan capture, abortyScan(), trigger release or timeout.
    BCS_BUTTON_SOFT,           //!< Triggers send events to framework for integrator to control scanning session via software calls.
    BCS_BUTTON_PASSIVE         //!< Triggers do not send events to framework. Integrator can control scanning session via software calls.
} ;


/** Verix BCS Application Host Responses **/
enum  commResult{
	COMM_RESULT_ACK=0,          //!< Response Acknowledged
	COMM_RESULT_NAK,            //!< Response Not Acknowledged
	COMM_RESULT_BUSY,           //!< Verix Application Busy
	COMM_RESULT_BAD_RESPONSE,   //!< Verix Application Bad Response
	COMM_RESULT_NO_RESPONSE     //!< Verix Application No Response
	
} ;

/** BCS Application Trigger Responses **/
enum  triggerResponse{
    BCS_TRIGGER_RELEASED = 0,       //!< Trigger Released
    BCS_TRIGGER_LEFT_PRESSED,       //!< Left Trigger Pressed
    BCS_TRIGGER_RIGHT_PRESSED       //!< Right Trigger Pressed
} ;





/** Protocol methods established for VFIBarcode class **/
@protocol VFIBarcodeDelegate <NSObject>

@optional
- (void) commandResult:(int)result;             //!< Receives int value #commResult. Monitoring this delegate will inform the success/failure from the Verix BCS application to API commands execute.
                                                //!< @param result #commResult

- (void) barcodeTriggerEvent:(int)BCS_TRIGGER;  //!< Receives int value #triggerResponse. When scanner is in Soft mode by executing VFIBarcode::setSoft(), this delegate will receive trigger press/release events values #triggerResponse.
                                                //!< @param BCS_TRIGGER #triggerResponse

- (void) barcodeLogEntry:(NSString*)logEntry withSeverity:(int)severity; //!<When VFIBarcode::logEnabled:() is passed <c>TRUE</c>, this delegate will receive log entries.
                                                //!< @param logEntry The log entry
                                                //!< @param severity The severitry of the log entry, with 0 indicating highest priority

- (void) barcodeSerialData:(NSData*)data  incoming:(BOOL)isIncoming; //!<All incoming/outgoing data going to the Barcode application can be monitored through this delegate.
                                            //!< @param data The serial data represented as a NSData object
                                            //!< @param isIncoming The direction of the data
                                            //!<- <c>TRUE</c> specifies data being received from barcode application,
                                            //!<- <c>FALSE</c> indicates data being sent to barcode application.

- (void) barcodeInitialized:(BOOL)isInitialized;//!<All incoming/outgoing data going to the Barcode application can be monitored through this delegate.
                                //!< @param isInitialized The direction of the data
                                //!<- <c>TRUE</c> specifies data being received from barcode application,
                                //!<- <c>FALSE</c> indicates data being sent to barcode application.


- (void) barcodeReconnectStarted;//!<When the External Accessory reports the barcode devices is detected (but not initialized by framework),this delegate is called. This signifies the beginning of the framework initialization proess.

- (void) barcodeReconnectFinished;//!<This signifies the end of the framework initialization proess.

- (void) barcodeConnected:(BOOL)isConnected;//!<Notified of barcode connection/disconnection events.  A connect/disconnect can either be from a physical disconnection/connection with the External Accessory API, or from an application going to backround or returning to foreground.
                                //!< @param isConnected A new connection or disconnection was detected
                                //!<- <c>TRUE</c> The barcode application has connected.
                                //!<- <c>FALSE</c> The barcode application has disconnected.

- (void) barcodeDataReceived:(NSData*)data;//!<This delegate monitors all data received from Barcode Application.
                                //!< @param data A NSData binary object representing the incoming data from the barcode.

- (void) barcodeDataSent:(NSData*)data;//!<This delegate monitors all data sent from Barcode Application.
                                //!< @param data A NSData binary object representing the outgoing data sent the barcode.

- (void) barcodeScanData:(NSData*)data barcodeType:(int)thetype;//!<This delegate receives the barcode scan data. If VFIBarcode::barcodeTypeEnabled:() is passed <c>TRUE</c>, then the parameter <c>thetype</c> will represent the barcode type int #barcodeTypes.
                                //!< @param data A NSData binary object representing the barcode data.
                                //!< - To convert the barcode data to a NSString, execute <c>[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]</c>
                                //!< @param thetype An int value representing the barcode type captured, using enum #barcodeTypes





@end

@class VFI_EADSessionController;

/**
 * API methods for Vx600 Pinpad Barcode Scanner.
 *
 * Implementing this class will allow API calls that will access Vx600 barcode hardware (if available).
 */
@interface VFIBarcode : NSObject <VFI_EADSessionControllerDelegate, EAAccessoryDelegate,NSStreamDelegate,UIApplicationDelegate> {
	
	id <VFIBarcodeDelegate> delegate;
	
}


/**
 * Creates an instance of VFIBarcode class.
 *
 * @retval <id> of VFIBarcode class
 *
 * Example Usage:
 * @code
 *    VFIBarcode* barcode = [[VFIBarcode alloc] init];
 * @endcode
 */
-(id)init;

/**
 * Initializes the barcode device.
 *
 * This is executed after the instance is created with init. If any of the optional protocols will be used, setDelegate should first be executed.
 *
 * Example Usage:
 * @code
 *    VFIBarcode* barcode = [[VFIBarcode alloc] init];
 *    [barcode setDelegate:self];
 *    [barcode initDevice];
 * @endcode
 */
-(void) initDevice;
/**
 * Powers up the scanner engine. 
 *
 * Executing startScan will allow barcode scanning to commence.
 */
-(void) startScan;

/**
 * Powers down the scanner engine.  
 *
 * Executing abortScan will remove power from the scanning engine deactivating barcode scanning.
 */
-(void) abortScan;

/**
 * Sends parameters to modify scanner properties.
 *
 * @param frame ISCP_HIGH packet containing command #frameType, group, FID,and parameters
 *
 * Creating ISCP_HIGH packets and sending them through this method sets various scanner properties.
 *
 * Example Usage:
 * To set the ability for the barcode scanner to recognize QR Codes, you must send #frameType \a TYPE_SETUP_WRITE, group 0x4b, fid 0x5a and parameters 0x00
 * @code
 ISCP_HIGH *frame = [[ISCP_HIGH alloc] init];
 frame.commandType = TYPE_SETUP_WRITE;
 frame.group = 0x4b;
 frame.fid = 0x5a;
 unsigned char* bytes = malloc(1);
 bytes[0] = 0x00;
 frame.param = bytes;
 [barcode sendISCP:frame];
 [frame release];
 * @endcode
 */
-(void) sendISCP:(ISCP_HIGH*)frame;

/**
 * Sets the default beep properties.
 *
 * @param beep T_BEEP_DEF packet containing Beep1, pause, and Beep2
 *
 * This method will configure the default beep properties.  This value does not persist between power resets. This method replaces setBeep:()
 *
 * Example Usage:
 * @code
 T_BEEP_DEF b;
 T_BEEP b1;
 T_BEEP b2;
 
 b1.freq = 0x40;
 b1.dur = 0x30;
 b2.freq = 0x35;
 b2.dur = 0x30;
 
 b.b1 = b1;
 b.b2 = b2;
 b.bPause = 0x50;
 
 [barcode configureBeep:b];
 * @endcode
 */
-(void) configureBeep:(T_BEEP_DEF)beep;

/**
 * \a DEPRECATED: Sets the default beep properties.
 *
 * @param beep T_BEEP_DEF packet containing Beep1, pause, and Beep2  
 *
 * \deprecated Please see configureBeep:()
 *
 */
-(void) setBeep:(T_BEEP_DEF)beep;

/**
 * Executes a barcode beep.
 *
 * @param beep T_BEEP_DEF packet containing Beep1, pause, and Beep2
 *
 * This method will execute a beep from the barcode scanner.
 *
 * Example Usage:
 * @code
 T_BEEP_DEF b;
 T_BEEP b1;
 T_BEEP b2;
 
 b1.freq = 0x40;
 b1.dur = 0x30;
 b2.freq = 0x35;
 b2.dur = 0x30;
 
 b.b1 = b1;
 b.b2 = b2;
 b.bPause = 0x50;
 
 [barcode sendBeep:b];
 * @endcode
 */
-(void) sendBeep:(T_BEEP_DEF)beep;

/**
 * Silences the barcode beep.
 *
 * This method will silence the beep that is executed upon a successful barcode scan.
 */
-(void) setBeepOff;

/**
 * Enables the barcode beep.  
 *
 * This method will allow the beep that is executed upon a successful barcode scan.
 */
-(void) setBeepOn;

/**
 * Retrieves the default barcode beep values.
 *
 * @retval getBeep #T_BEEP_DEF structure that contains Beep1, Beep2, and the pause between them.
 *
 * This method polls the barcode for the current default beep values.
 */
-(T_BEEP_DEF) getBeep;

/**
 * Sets barcode scanner timeout.
 *
 * @param milliseconds Interval that must pass in milliseconds before timeout error.
 *
 * While in Edge mode setEdge(), clicking the trigger with the scanner engine ON will power the scanner light and remain on until a successful scan or the timeout threshold is reached that is set by this method.
 */
-(void) setScanTimeout:(long)milliseconds;

/**
 * Sets barcode scanner in 2D mode.
 *
 * Changes the scanning characteristics to read barcodes that two dimensional.
 */
-(void) setScanner2D;

/**
 * Sets barcode scanner in 1D mode. 
 *
 * Changes the scanning characteristics to read barcodes that are linear and one dimensional.
 */
-(void) setScanner1D;

/**
 * Enables continuous scanning of barcodes.   
 *
 * While in Edge Mode setEdge() or Level Mode setLevel(), after a successful scan, the scanning light will remain on ready to capture the next barcode.
 */
-(void) setMultiScan;

/**
 * Disables continuous scanning of barcodes.
 *
 * While in Edge Mode setEdge() or Level Mode setLevel(), after a successful scan, the scanning light will turn off. This is default behavior.
 */
-(void) setSingleScan;

/**
 * Barcode application version.  
 *
 * After the successful execution of this blocking method, the barcode application version can be retrieved by polling the property #barcodeVersion.
 */
-(void) getVersion;

/**
 * Sets Level Scanning Mode. 
 *
 * A reading session begins (lighting and decode processing on) when the Trigger line is activated. The reading session stops when an abortScan() is executed, barcode data is received, trigger line deactivated, or a timeout setScanTimeout:() is reached. This differs from Edge Mode setEdge() in the fact that you need to continue to depress the trigger to keep the lighting and decode processing on.
 */
-(void) setLevel;

/**
 * Sets Edge Scanning Mode. 
 *
 * A reading session begins (lighting and decode processing on) when the Trigger line is activated. The reading session stops when an abortScan() is executed, barcode data is received, or a timeout setScanTimeout:() is reached. This differs from Level Mode setLevel() in the fact that you do not need to continue to depress the trigger to keep the lighting and decode processing on. The light remains on after you release the trigger.
 */
-(void) setEdge;

/**
 * Sets Software Scanning Mode. 
 *
 * A reading session begins (lighting and decode processing on) when sendTriggerEvent:() \a TRUE is sent. The reading session stops when an abortScan() is executed, barcode data is received, sendTriggerEvent:() \a FALSE is sent or a timeout setScanTimeout:() is reached. Pressing the trigger does not activate the light.  Trigger press/release events sends data to the delegate VFIBarcodeDelegate::barcodeTriggerEvent:()   This differs from Passive Mode setPassive() in the fact that you do not get any trigger press events in Passive Mode.
 */
-(void) setSoft;

/**
 * Sets Passive Scanning Mode. 
 *
 * A reading session begins (lighting and decode processing on) when sendTriggerEvent:() \a TRUE is sent. The reading session stops when an abortScan() is executed, barcode data is received, sendTriggerEvent:() \a FALSE is sent or a timeout setScanTimeout:() is reached. Pressing the trigger does not activate the light.  Trigger press/release events does not send any data to the delegate VFIBarcodeDelegate::barcodeTriggerEvent:()   This differs from Soft Mode setSoft() in the fact that you do not get any trigger press events in Passive Mode.
 */
-(void) setPassive;

/**
 * Enabled logging to delegate.
 *
 * @param enable Setting \a TRUE enables logging to VFIBarcodeDelegate::barcodeLogEntry:withSeverity:()
 */
-(void) logEnabled:(BOOL)enable;

/**
 * Enabled logging to XCode Console.
 *
 * @param enable Setting \a TRUE enables additional logging to debug console window in iOS 
 */
-(void) consoleEnabled:(BOOL)enable;

/**
 * Duplicate barcode checking.
 *
 * @param enable Setting \a TRUE will filter out any duplicte barcodes that have been scanned since this value was set.
 */
-(void) ignoreDuplicates:(BOOL)enable;

/**
 * Clears duplicate barcode checking buffer.
 *
 * Calling this method will reset the duplicate barcode checking buffer.
 */
-(void) clearDuplicatesBuffer;

/**
 * Software control of scanner light.
 *
 * @param activate While is Soft Mode setSoft() or Passive Mode setPassive(), setting \a TRUE will enabable the scanner light, while \a false will deactivate it.
 */
-(void) sendTriggerEvent:(BOOL)activate;


/**
 * Enabled barcode type reporting.
 *
 * @param enable Setting \a TRUE enables barcode types to be sent with barcode scan data to VFIBarcodeDelegate::barcodeScanData:thetype:()
 */
-(void) barcodeTypeEnabled:(BOOL)enable;

/**
 * Reset Scanner. 
 *
 * Resets scanner engine to factory defaults.
 */
-(void) resetScannerToFactoryDefaults;

/**
 * Enable automatic trigger events in Soft Mode.
 *
 * @param enable Setting \a TRUE enables automatic sending of sendTriggerEvent:() when VFIBarcodeDelegate::barcodeTriggerEvent:() receives a trigger event.
 */
-(void) setScanButtonMode:(BOOL)enable;

/**
 * Returns scan button mode. 
 *
 * @retval BOOL Current scan button mode that the framework is operating in.  
 */
-(BOOL) getScanButtonMode;

/**
 * Clears barcode type filtering look up table. 
 *
 * When barcode data is received, if there are any entries in the filter look up table from executing excludeBarcodeType:(), the table is scanned for a match to the current barcode data, and if match is found, that barcode is NOT passed to the integrator.  This method clears out the filter look up table so no filtering will take place while the filtering look up table has 0 entries in it.
 */
-(void) includeAllBarcodeTypes;

/**
 * Removes a barcode type from the filtering look up table.
 *
 * @param type The barcode to EXCLUDE from the filtering look up table.  Value is from #barcodeTypes
 *
 * This method will insure that the desired barcode will not be filtered by any previous table insertions of the desired barcode type into the filtering look up table.
 */
-(void) includeBarcodeType:(int)type;

/**
 * Adds a barcode type from the filtering look up table.
 *
 * @param type The barcode to INCLUDE from the filtering look up table.  Value is from #barcodeTypes
 *
 * This method will filter out the desired barcode type.
 */
-(void) excludeBarcodeType:(int)type;

/**
 * Activates barcode type recognition in scanner.
 *
 * @param type The barcode to ACTIVATE RECOGNITION in the scanner.  Value is from #barcodeTypes
 *
 * This method sends appropriate ISCP command to the scanner to turn on the recognition of specific barcode types.
 */
-(void) activateBarcodeType:(int)type;

/**
 * Deactivates barcode type recognition in scanner.
 *
 * @param type The barcode to DEACTIVATE RECOGNITION in the scanner.  Value is from #barcodeTypes
 *
 * This method sends appropriate ISCP command to the scanner to turn off the recognition of specific barcode types.
 */
-(void) deactivateBarcodeType:(int)type;

/**
 * Allows direct stream access to Barcode Application.
 *
 * @param data The data to send to the barcode application
 *
 * This method will pass the provided NSData object directly to the barcode input stream.
 */
-(void) executeCmd:(NSData*)data;

/**
 * Controls beep execution after succssful scan
 *
 * @param enable A value of \a TRUE will allow a beep to be played after a successful barcode capture, while \a FALSE will supress the beep.
 *
 * Barcode beep is ON by default.
 */
-(void) beepOnParsedScan:(BOOL)enable;


/**
 * Ignore/Respond to trigger press events
 *
 * @param enable A value of \a TRUE will respond to trigger press events during Soft Mode. A value of \a FALSE will ignore trigger press events
 *
 * This convenience funtion allows the integrator to stay in Soft Mode and be able to ignore trigger presses without having to shut down power to scanner with an abortScan().
 */
-(void) enableSoftTrigger:(BOOL)enable;

/**
 * Terminates stream connection to Barcode
 *
 * This method will shut down the connection to the Barcode stream. An initDevice() will need to be executed again to engage a new stream connection.
 */
-(void) closeDevice;

/**
 * Controls the restart loop delay
 *
 * @param sec The amount of time in fractional sections to wait between attempts in establishing contact to Vx600 while waiting for initialization
 *
 * Default is 1.0 seconds.
 */
-(void) restartLoopDelay:(float)sec;

/**
 * Controls the amount of looping attempts to contact barcode application.
 *
 * @param loop The number of loops in establishing contact to Vx600 while waiting for initialization 
 *
 * If the Vx600 is unresponsive, the framework will loop the specified number of times, with a delay of restartLoopDelay:() between each attempt. The default is 59 loops.
 */
-(void) setInitLoop:(int) loop;

/**
 * Sets Barcode Trigger Mode.
 *
 * @param mode Barcode trigger mode, selected from #scanningModes
 * 
 * This one method can have the same outcome as calling any one of the methods setSoft, setPassive, setLevel, setEdge.
 */
-(void) setTrigger:(int)mode;






@property (retain) id <VFIBarcodeDelegate>delegate;                 //!< Gets or Sets delegate for protocols
@property (nonatomic, readonly) NSString *barcodeName;              //!< Read Only name reported to External Accessory
@property (nonatomic, readonly) NSString *barcodeManufacturer;      //!< Read Only Manufacturer reported to External Accessory
@property (nonatomic, readonly) NSString *barcodeModelNumber;       //!< Read Only Model Number reported to External Accessory
@property (nonatomic, readonly) NSString *barcodeSerialNumber;      //!< Read Only Serial Number reported to External Accessory
@property (nonatomic, readonly) NSString *barcodeFirmwareRevision;  //!< Read Only Firmware Version reported to External Accessory
@property (nonatomic, readonly) NSString *barcodeHardwareRevision;  //!< Read Only Hardware Version reported to External Accessory
@property (nonatomic, readonly) NSString *barcodeVersion;           //!< Read Only Barcode App version set by by getVersion()
@property (readonly) BOOL barcodeConnected;                         //!< Read Only Boolean barcode connection status
@property (readonly) BOOL connected;                                //!< Read Only Boolean barcode connection status
@property (readonly) BOOL BTconnected;                              //!< Read Only Boolean barcode Vx600 Bluetooth connection Status
@property (readonly) BOOL initialized;                              //!< Read Only Boolean barcode initialized








@end

