

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import	<ExternalAccessory/ExternalAccessory.h>
#import "VFICardData.h"
#import "VFIBINRange.h"
#import "VFIDataEntry.h"
#import "VFICipheredData.h"
#import "VFIZontalk.h"
#import "VFIDiagnostics.h"
#import "VFIEMVAuthorization.h"
#import "VFIEMVCompletionData.h"
#import "VFIEMVConfiguration.h"
#import "VFIEMVResponse.h"
#import "VFIEncryptionData.h"
#import "VFIFinancialData.h"
#import "VFIEMVTags.h"
#import "VFIZipArchive.h"
#import "VFIControl.h"
#import "VFIBarcode.h"

#import "NSData-AES.h"
#import "Base64.h"

#include "VFI_zip.h"
#include "VFI_unzip.h"




#define frameworkTimeoutErrorCode 999;
/** Protocol methods established for VFIPinpad class **/
@protocol VFIPinpadDelegate <NSObject>

@optional
- (void) pinpadResultCode:(NSString*)command result:(int)code;
- (void) pinpadLogEntry:(NSString*)logEntry withSeverity:(int)severity;
- (void) pinpadSerialData:(NSData*)data  incoming:(BOOL)isIncoming;
- (void) pinpadMSRData:(NSString*)pan  expMonth:(NSString*)month  expYear:(NSString*)year  trackData:(NSString*)track2;
- (void) pinpadMSRData:(NSString*)pan  expMonth:(NSString*)month  expYear:(NSString*)year  track1Data:(NSString*)track1  track2Data:(NSString*)track2;
- (void) pinpadDownloadInfo:(NSString*)log;
- (void) pinpadDownloadBlocks:(int)TotalBlocks sent:(int)BlocksSent;
- (void) pinPadInitialized:(BOOL)isInitialized;
- (void) lrcCalc:(int)reported calc:(int)calculated;

- (void) pinpadReconnectStarted;
- (void) pinpadReconnectFinished;

- (void) pinpadConnected:(BOOL)isConnected;
- (void) pinpadDataReceived:(NSData*)data;
- (void) pinpadDataSent:(NSData*)data;
@end

typedef enum{
	VFIResultCode_ACK_Timeout = -2,
	VFIResultCode_Framework_Timeout = -1
	
} VFIErrorCode;

typedef enum{
	EncryptionMode_VSP,
	EncryptionMode_PKI,
	EncryptionMode_NOE	
	
} EncryptionMode;

enum SEVERITY_LOG_LEVELS {
    SEV_DEBUG=0,
    SEV_INFO_PINPAD=1,
    SEV_WARN=2,
    SEV_ERROR=3,
    SEV_FATAL=4,
    SEV_UNKOWN=5
};

@class VFI_EADSessionController;

/**
 * API methods for Vx600 for XPI.
 *
 * Implementing this class will allow access to API calls that will perform Vx600 XPI command.
 */
@interface VFIPinpad : NSObject <VFI_EADSessionControllerDelegate, EAAccessoryDelegate, NSStreamDelegate,VFIZontalkDelegate, UIApplicationDelegate> {
	
	id <VFIPinpadDelegate> delegate;
	EAAccessory *_accessory;
	VFI_EADSessionController *_eaSessionController;
	VFIZontalk *zonTalk;
	VFICardData *vfiCardData;
	VFICipheredData *vfiCipheredData;
	VFIEMVTags *vfiEMVTags;
	VFIDiagnostics *vfiDiagnostics;
	NSMutableArray *vfiEMVRequiredTags;
	VFIEMVAuthorization *vfiEMVAuthorization;
	VFIEMVCompletionData *vfiEMVCompletionData;
	//VFIFinancialData *vfiFinancialData;
	VFIEncryptionData *vfiEncryptionData;
	NSRunLoop *theRL;
	UIBackgroundTaskIdentifier bgTask;
	

}



+ (VFIPinpad *)sharedController;
-(void) ignoreDisconnect;
+(NSString*) VMF_Version;
-(id)init;
-(id)initOnThread;
-(void) setInitLoop:(int) loop;
-(void) initDevice:(NSNotification *)notification;
-(void) deviceDisconnected:(NSNotification *)notification;
-(void) deviceDisconnected2:(NSNotification *)notification;
-(void) deviceDisconnected3:(NSNotification *)notification;
-(void) initDevice;
-(void) initBridge;
-(void)removeListeners;
-(void) closeDevice;
-(void) enableCTLS;
-(void) disableCTLS;
-(void) enableBlocking;
-(void) disableBlocking;
-(void) setKSN20Char:(BOOL)is20Char;
-(void)pause:(float)sec;
-(void)deviceDisconnectedBridge:(NSNotification *)notification;
-(void) terminateConnectionThread;
-(void) terminateDisonnectionThread;
-(void) updateFromUrl:(NSString*)theURL;
-(void) updateFromZip:(NSData*)data;
-(int) sendStringCommand:(NSString*)cmd calcLRC:(BOOL)lrc;
-(int) sendDataCommand:(NSMutableData*)cmd calcLRC:(BOOL)lrc;
-(void) simulatorMode:(BOOL)activate;
-(void) setACKTimeout:(int)seconds;
-(void) setCommunicationID:(NSString *)commID;
-(id) initWithCommunicationID:(NSString *) commID;
-(void) cancelPendingCommand;

-(void) setFrameworkTimeout:(int)seconds;
-(void) setPromptTimeout:(int)seconds;
-(void) setPINTimeout:(int)seconds;
-(void) setAccountEntryTimeout:(int)seconds;
-(void) setContinueTransactionTimeout:(int)seconds;
- (void) PS02:(int)timeout;
- (void) setIOTimer:(int)timeout;
-(void) ack_True;

-(void) waitForResponse:(BOOL)wait;
-(void) processResponse:(NSData *)data;
-(void) clearAllData;
-(BOOL) checkLRC:(NSData *)data;
-(void) restartLoopDelay:(float)sec;
-(NSString*) getLog;
-(NSString*) getZontalkLog;
-(NSString*) getLogFilename;
-(void) writeLog:(NSString*)log withSeverity:(int)severity;
-(void) clearLog;
-(void) clearZontalkLog;
-(void) logEnabled:(BOOL)enable;
-(void) consoleEnabled:(BOOL)enable;

//-(void) performBreak;

-(void)setParameterArray:(NSMutableArray*)parameters;
-(void)setParameter:(NSString*)parmName value:(NSString*)parmValue;
-(int) S95;
-(int) diagnosticInfo;

-(int) clearCAPK;
-(int) D12;

-(NSString *) resultD11;
-(NSString *) copyCAPKFile;
-(NSString *) copyStringResponse;
-(NSDictionary *) copyLastEMVTags;
-(NSString*) ctlsOPTFLAG;
-(int) ctlsState;

-(void) S01;
-(void) initializeIdle;

- (int) S68;
- (int) testPINPad;


- (void) Q41;
- (void) disableMSR;

- (void) Q40;
- (void) enableMSR;

- (void) Q42;
- (void) enableMSRDualTrack;


- (void) PS01:(NSString*)symbol;
- (void) setCurrencySymbol:(NSString*)symbol;




-(int) D11:(NSString *)RID pkIndex:(int)index modulus:(NSData *)modulus exponent:(NSData *)exp checksum:(NSData *)csum expiryDate:(NSDate *)date;
-(int) createCAPK:(NSString *)RID pkIndex:(int)index modulus:(NSData *)modulus exponent:(NSData *)exp checksum:(NSData *)csum expiryDate:(NSDate *)date;

-(int) D27;
-(int) statusCTLS;


-(int) D16:(NSString *)tableID numRecords:(int)reccnt;
-(int) createTable:(NSString *)tableID numRecords:(int)reccnt;

-(int) D18:(NSData *)termCAPQPS sig:(NSData *)termCAPSig CVM:(float)cvmAmount;
-(int) initializeContactless:(NSData *)termCAPQPS sig:(NSData *)termCAPSig CVM:(float)cvmAmount;

-(int) D25:(BOOL)visaDebitFlag ctlsMode:(int)mode pdolSupport:(BOOL)pdolFlag;
-(int) setAdditionalEVMFlags:(BOOL)visaDebitFlag ctlsMode:(int)mode pdolSupport:(BOOL)pdolFlag;

-(int) D13:(int)recno AID:(int)aidNo partialNameMatch:(BOOL)flag supportedAID:(NSData *)supAID termAVN:(NSData *)avn term2ndAVN:(NSData *)avn2 recommendedAIDName:(NSString *)aidName;
-(int) updateAIDRecord:(int)recno AID:(int)aidNo partialNameMatch:(BOOL)flag supportedAID:(NSData *)supAID termAVN:(NSData *)avn term2ndAVN:(NSData *)avn2 recommendedAIDName:(NSString *)aidName;

-(int) D14:(int)recno tableData:(VFIEMVConfiguration* )emvData;
-(int) updateEMVConfigRecord:(int)recno tableData:(VFIEMVConfiguration* )emvData;

-(int) D19:(int)recno mvtIndex:(int)emvIndex groupName:(NSString *)group ctlsFloorLimit:(float)ctlsFloor ctlsCVMLimit:(float)ctlsCVM ctlsTranLimit:(float)ctlsTran ctlsTacDefault:(NSData *)tacDefault ctlsTacDenial:(NSData *)tacDenial ctlsTacOnline:(NSData *)tacOnline visaTTQ:(NSData *)ttq termCapabilities:(NSString*)termCapb addTermCapabilities:(NSString*)addTermCapb;
-(int) updateExtendedEMVRecord:(int)recno mvtIndex:(int)emvIndex groupName:(NSString *)group ctlsFloorLimit:(float)ctlsFloor ctlsCVMLimit:(float)ctlsCVM ctlsTranLimit:(float)ctlsTran ctlsTacDefault:(NSData *)tacDefault ctlsTacDenial:(NSData *)tacDenial ctlsTacOnline:(NSData *)tacOnline visaTTQ:(NSData *)ttq termCapabilities:(NSString*)termCapb addTermCapabilities:(NSString*)addTermCapb;

-(int) D19:(int)recno mvtIndex:(int)emvIndex groupName:(NSString *)group ctlsFloorLimit:(float)ctlsFloor ctlsCVMLimit:(float)ctlsCVM ctlsTranLimit:(float)ctlsTran ctlsTacDefault:(NSData *)tacDefault ctlsTacDenial:(NSData *)tacDenial ctlsTacOnline:(NSData *)tacOnline visaTTQ:(NSData *)ttq;
-(int) updateExtendedEMVRecord:(int)recno mvtIndex:(int)emvIndex groupName:(NSString *)group ctlsFloorLimit:(float)ctlsFloor ctlsCVMLimit:(float)ctlsCVM ctlsTranLimit:(float)ctlsTran ctlsTacDefault:(NSData *)tacDefault ctlsTacDenial:(NSData *)tacDenial ctlsTacOnline:(NSData *)tacOnline visaTTQ:(NSData *)ttq;



-(int) D20:(int)recno ctlsMerchantType:(int)merchType ctlsTermTransInfo:(NSString*)transInfo ctlsTermTransType:(NSString*)transType ctlsReqReceiptLimit:(float)ctlsReceipt ctlsOptionStatus:(NSString*)optionStatus ctlsReaderFlooorLimit:(float)ctlsFloor;
-(int) updateICCT:(int)recno ctlsMerchantType:(int)merchType ctlsTermTransInfo:(NSString*)transInfo ctlsTermTransType:(NSString*)transType ctlsReqReceiptLimit:(float)ctlsReceipt ctlsOptionStatus:(NSString*)optionStatus ctlsReaderFlooorLimit:(float)ctlsFloor;

-(int) D17:(int)recno emvRecord:(int)emvRecno AID:(NSString *)aid maxAIDLen:(int)maxLen appFlow:(NSString *)flow partialName:(BOOL)pflag acctSelect:(BOOL)aflag enableCtls:(BOOL)cflag;
-(int) updateExtendedSchemeRecord:(int)recno emvRecord:(int)emvRecno AID:(NSString *)aid maxAIDLen:(int)maxLen appFlow:(NSString *)flow partialName:(BOOL)pflag acctSelect:(BOOL)aflag enableCtls:(BOOL)cflag;

-(int) D17:(int)recno emvRecord:(int)emvRecno AID:(NSString *)aid maxAIDLen:(int)maxLen appFlow:(NSString *)flow partialName:(BOOL)pflag acctSelect:(BOOL)aflag enableCtls:(BOOL)cflag transScheme:(int)scheme;
-(int) updateExtendedSchemeRecord:(int)recno emvRecord:(int)emvRecno AID:(NSString *)aid maxAIDLen:(int)maxLen appFlow:(NSString *)flow partialName:(BOOL)pflag acctSelect:(BOOL)aflag enableCtls:(BOOL)cflag transScheme:(int)scheme;



-(int) D15:(int)recno numberTrans:(long)numTrans scheme:(NSString *)schemeLabel regId:(NSString *)RID CSNList:(NSString *)csn emvTableRecord:(long)rec CSNFile:(NSString *)csnFile;
-(int) updateSchemeRecord:(int)recno numberTrans:(long)numTrans scheme:(NSString *)schemeLabel regId:(NSString *)RID CSNList:(NSString *)csn emvTableRecord:(long)rec CSNFile:(NSString *)csnFile;


-(void) initiateDownload:(BOOL)isPartial;
-(NSArray *) getBINRange:(NSString *)accountNumber;
-(int) setBINRange:(VFIBINRange *)binRecord;

//-(int) setTransactionParametersForTransaction:(NSString *)txType tipFlag:(BOOL)tipFlag cashBack:(BOOL)cbFlag surcharge:(int)scOption surchargeAmt:(float)scAmt;

-(int) C32:(float)amount otherAmount:(float)amtOther merchantDecision:(int)decision minRequestObjects:(NSMutableArray *)reqObjArray;
-(int) cardAuthorization:(float)amount otherAmount:(float)amtOther merchantDecision:(int)decision minRequestObjects:(NSMutableArray *)reqObjArray;


-(int) C32:(float)amount otherAmount:(float)amtOther merchantDecision:(int)decision minRequestObjects:(NSMutableArray *)reqObjArray displayResult:(BOOL)display;
-(int) cardAuthorization:(float)amount otherAmount:(float)amtOther merchantDecision:(int)decision minRequestObjects:(NSMutableArray *)reqObjArray displayResult:(BOOL)display;

-(int) C32:(float)amount otherAmount:(float)amtOther merchantDecision:(int)decision minRequestObjects:(NSMutableArray *)reqObjArray displayResult:(BOOL)display pinTryExceedStatus:(BOOL)pinTry displayAmount:(BOOL)displayAmt;
-(int) cardAuthorization:(float)amount otherAmount:(float)amtOther merchantDecision:(int)decision minRequestObjects:(NSMutableArray *)reqObjArray displayResult:(BOOL)display pinTryExceedStatus:(BOOL)pinTry displayAmount:(BOOL)displayAmt;

-(int) C32:(float)amount otherAmount:(float)amtOther merchantDecision:(int)decision minRequestObjects:(NSMutableArray *)reqObjArray displayResult:(BOOL)display pinTryExceedStatus:(BOOL)pinTry displayAmount:(BOOL)displayAmt displayAppExpired:(BOOL)displayAppExpired;
-(int) cardAuthorization:(float)amount otherAmount:(float)amtOther merchantDecision:(int)decision minRequestObjects:(NSMutableArray *)reqObjArray displayResult:(BOOL)display pinTryExceedStatus:(BOOL)pinTry displayAmount:(BOOL)displayAmt displayAppExpired:(BOOL)displayAppExpired;


-(int) S11:(NSString *)msg1 line2:(NSString *)msg2;
-(int) displayMessageAndWait:(NSString *)msg1 line2:(NSString *)msg2;

-(int) S11:(NSString *)msg1 line2:(NSString *)msg2 line3:(NSString *)msg3 line4:(NSString *)msg4;
-(int) displayMessageAndWait:(NSString *)msg1 line2:(NSString *)msg2 line3:(NSString *)msg3 line4:(NSString *)msg4;



-(int) C18:(uint)floorLimit threshold:(uint)thresh target:(uint)targ targetPercent:(uint)percent;

-(int) setROSParams:(uint)floorLimit threshold:(uint)thresh target:(uint)targ targetPercent:(uint)percent;
-(void) S00;
-(void) cancelCommand;
-(int) C34:(int)hostDecision displayResult:(BOOL)flag hostTags:(NSMutableDictionary*)hostTagData;
-(int) completeOnlineEMV:(int)hostDecision displayResult:(BOOL)flag hostTags:(NSMutableDictionary*)hostTagData;
-(NSString *) copyPromptData;
-(int) Z60:(NSString *)accountNumber;
-(int) acceptEncryptPIN:(NSString *)accountNumber;
-(int) Z62:(NSString *)accountNumber minPIN:(int)min maxPIN:(int)max requirePIN:(BOOL)req firstMessage:(NSString*)msg1 secondMessage:(NSString*)msg2 processingMessage:(NSString*)procMsg ;
-(int) acceptEncryptPINMessage:(NSString *)accountNumber minPIN:(int)min maxPIN:(int)max requirePIN:(BOOL)req firstMessage:(NSString*)msg1 secondMessage:(NSString*)msg2 processingMessage:(NSString*)procMsg ;

//-(int) S67:(NSString *)accountNumber;
//-(int) requestPINRentry:(NSString *)accountNumber;


-(void) S07:(int)displayTimer pin:(int)pinTimer balance:(int)balanceTimer;
-(void) storeTimers:(int)displayTimer pin:(int)pinTimer balance:(int)balanceTimer;


-(NSMutableDictionary*) convertTLVtoDict:(NSData*)param;

-(EncryptionMode) E00;
-(EncryptionMode) getEncryptionMode;

-(EncryptionMode) E10:(EncryptionMode)mode;
-(EncryptionMode) selectEncryptionMode:(EncryptionMode)mode;

-(int) E02;
-(int) retrieveEParmsData;

-(int) E04;
-(int) performTGKUpdateRequest;

-(int) E06;
-(int) getPKICipheredData;


-(int) E08_RSA:(NSString*)publicKeyRSA publicKeyID:(NSString*)keyID;
-(int) loadKeyInformation_RSA:(NSString*)publicKeyRSA publicKeyID:(NSString*)keyID;

-(int) E08_x509:(NSString*)publicKeyX509;
-(int) loadKeyInformation_x509:(NSString*)publicKeyX509;

-(int) E12:(int)type p75Data:(NSData*)data;
-(int) loadPKISig:(int)type p75Data:(NSData*)data;


-(int) S66:(NSData *)macData;
-(int) createMac:(NSData *)macData;
-(int) S16:(int)lcode;
-(int) obtainCardData:(int)lcode;
-(int) S16:(int)lcode displayIdle:(BOOL)display;
-(int) obtainCardData:(int)lcode displayIdle:(BOOL)display;
-(int) S20:(int)timeout optionalAmount:(float)amount;
-(int) S21prompt:(NSString*)prompt;
-(int) dataEntryRequestPrompt:(NSString*)prompt;
-(int) S21:(float)amount language:(int)lcode tip:(BOOL)tipFlag cashback:(BOOL)cashbackFlag surcharge:(float)surchgAmt;
-(int) dataEntryRequest:(float)amount language:(int)lcode tip:(BOOL)tipFlag cashback:(BOOL)cashbackFlag surcharge:(float)surchgAmt;

-(int) S23:(float)amount language:(int)lcode transID:(int)ID menuArray:(NSString*)promptArray surcharge:(float)surchgAmt accountNum:(NSString*)account tipOptions:(NSString*)tipOpt cashBackOptions:(NSString*)cashBackOpt surchargeOptions:(int)surchargeOpt;
-(int) combinedPromptCommand:(float)amount language:(int)lcode transID:(int)ID menuArray:(NSString*)promptArray surcharge:(float)surchgAmt accountNum:(NSString*)account tipOptions:(NSString*)tipOpt cashBackOptions:(NSString*)cashBackOpt surchargeOptions:(int)surchargeOpt;

-(void) S14:(NSString *)line1 Line2:(NSString*)line2 Line3:(NSString*)line3 Line4:(NSString*)line4 timeout:(int)timeout;
-(void) displayMessages:(NSString *)line1 Line2:(NSString*)line2 Line3:(NSString*)line3 Line4:(NSString*)line4 timeout:(int)timeout;
-(void) S14:(NSString *)line1 Line2:(NSString*)line2 Line3:(NSString*)line3 Line4:(NSString*)line4;
-(void) displayMessages:(NSString *)line1 Line2:(NSString*)line2 Line3:(NSString*)line3 Line4:(NSString*)line4;
-(int) S70:(int)transId language:(int)lcode amount:(float)amt pan:(NSString *)acctNumber mac:(NSData *)macData;
-(int) doInteracRequest:(int)transId language:(int)lcode amount:(float)amt pan:(NSString *)acctNumber mac:(NSData *)macData;
-(NSData *) encryptCardData:(NSString *)accountNumber expiry:(NSDate *)date;
-(int) S12:(NSString *)msgID1 message2:(NSString *)msgID2 minLength:(int)minLen maxLength:(int)maxLen language:(int)lcode allowSkip:(BOOL)flag  secureEntry:(BOOL)secure  displayCanceled:(BOOL)display  restoreScreen:(BOOL)restore;
-(int) generalPrompt:(NSString *)msgID1 message2:(NSString *)msgID2 minLength:(int)minLen maxLength:(int)maxLen language:(int)lcode allowSkip:(BOOL)flag secureEntry:(BOOL)secure  displayCanceled:(BOOL)display  restoreScreen:(BOOL)restore;	
-(int) S12Default:(NSString *)msgID1 message2:(NSString *)msgID2 minLength:(int)minLen maxLength:(int)maxLen language:(int)lcode initialValue:(NSString *)defaultValue allowSkip:(BOOL)flag;
-(int) generalPromptDefault:(NSString *)msgID1 message2:(NSString *)msgID2 minLength:(int)minLen maxLength:(int)maxLen language:(int)lcode initialValue:(NSString *)defaultValue allowSkip:(BOOL)flag;
-(int) S12:(NSString *)msgID1 message2:(NSString *)msgID2 minLength:(int)minLen maxLength:(int)maxLen language:(int)lcode allowSkip:(BOOL)flag secureEntry:(BOOL)secure;
-(int) generalPrompt:(NSString *)msgID1 message2:(NSString *)msgID2 minLength:(int)minLen maxLength:(int)maxLen language:(int)lcode allowSkip:(BOOL)flag secureEntry:(BOOL)secure;
-(int) C30:(int)timeout language:(int)lcode amount:(float)txnAmt otherAmount:(float)txnOthAmt;
-(int) getCardData:(int)timeout language:(int)lcode amount:(float)txnAmt otherAmount:(float)txnOthAmt;
-(int) C36:(NSMutableArray *)tagArray;
-(int) getEMVTags:(NSMutableArray *)tagArray;
-(int) S13:(NSString *)msg1 message2:(NSString *)msg2 choice1:(NSString *)cho1 choice2:(NSString *)cho2 choice3:(NSString *)cho3 choice4:(NSString *)cho4;
-(int) menuChoiceSelection:(NSString *)msg1 message2:(NSString *)msg2 choice1:(NSString *)cho1 choice2:(NSString *)cho2 choice3:(NSString *)cho3 choice4:(NSString *)cho4;
-(int) I02;
-(int) removeCard;
-(int) C19:(NSData *)tag value:(NSData *)tagValue;
-(int) setEMVTag:(NSString *)tag value:(NSData *)tagValue;
-(int) Z50:(int)echoFlag timeout:(int)timeout maxLen:(int)length;
-(int) requestStringInput:(int)echoFlag timeout:(int)timeout maxLen:(int)length;

-(int) Z50:(int)echoFlag timeout:(int)timeout maxLen:(int)length entryType:(int)type;
-(int) requestStringInput:(int)echoFlag timeout:(int)timeout maxLen:(int)length entryType:(int)type;


-(int) Z52:(NSString*)message echo:(int)echoFlag timeout:(int)timeout maxLen:(int)length entryType:(int)type;
-(int) displayMessagePromptInput:(NSString*)message echo:(int)echoFlag timeout:(int)timeout maxLen:(int)length entryType:(int)type;


-(int) Z2:(NSString *)string clearScreen:(BOOL)clear;
-(int) displayMessage:(NSString *)string clearScreen:(BOOL)clear;
-(int) C21:(NSMutableDictionary*)tagArray;
-(int) setEMVTags:(NSMutableDictionary*)tagArray;
-(int) writeToScriptFile:(int)scriptId clear:(BOOL)flag numScripts:(int)num length:(int)scriptLen data:(NSData *)scriptData;
-(int) C25:(int)scriptId clear:(BOOL)flag numScripts:(int)num length:(int)scriptLen data:(NSData *)scriptData;
-(int) S71:(NSData *)macBlock language:(int)lcode pinKey:(NSData *)tpkKey macKey:(NSData *)takKey msgLine1:(NSString *)msg1 msgLine2:(NSString *)msg2 macData:(NSData *)data;
-(int) validateMacResponse:(NSData *)macBlock language:(int)lcode pinKey:(NSData *)tpkKey macKey:(NSData *)takKey msgLine1:(NSString *)msg1 msgLine2:(NSString *)msg2 macData:(NSData *)data;
-(int) S71Fields:(NSData *)macBlock language:(int)lcode msgLine1:(NSString *)msg1 msgLine2:(NSString *)msg2 macData:(NSData *)macdata identity1:(NSData*)identity1 data1:(NSData*)data1 identityK:(NSData*)identityK dataK:(NSData*)dataK;
-(int) validateMacResponseFields:(NSData *)macBlock language:(int)lcode msgLine1:(NSString *)msg1 msgLine2:(NSString *)msg2 macData:(NSData *)macdata identity1:(NSData*)identity1 data1:(NSData*)data1 identityK:(NSData*)identityK dataK:(NSData*)dataK;

-(NSString*)getOSVersion;  //M01 returns OS version
-(NSString*)getXPIVersion;  //M01 returns XPI Version

-(void) noResponseNextCommand;
-(void)processReceivedData:(NSData*)data;
- (void)channelConnection:(NSString *)channelResponse;

@property (retain) id delegate;
@property (nonatomic, retain) VFICardData	*vfiCardData;
@property (nonatomic, retain) VFIDataEntry	*vfiDataEntry;
@property (nonatomic, retain) VFICipheredData	*vfiCipheredData;
@property (nonatomic, retain) VFIEMVTags	*vfiEMVTags;
@property (nonatomic, retain) VFIDiagnostics	*vfiDiagnostics;
@property (nonatomic, retain) NSMutableArray	*vfiEMVRequiredTags;
@property (nonatomic, retain) VFIEMVAuthorization	*vfiEMVAuthorization;
@property (nonatomic, retain) VFIEMVCompletionData	*vfiEMVCompletionData;
//@property (nonatomic, retain) VFIFinancialData	*vfiFinancialData;
@property (nonatomic, retain) VFIEncryptionData	*vfiEncryptionData;


@property (nonatomic, readonly) NSString *pinpadName;
@property (nonatomic, readonly) NSString *pinpadManufacturer;
@property (nonatomic, readonly) NSString *pinpadModelNumber;
@property (nonatomic, readonly) NSString *pinpadSerialNumber;
@property (nonatomic, readonly) NSString *pinpadFirmwareRevision;
@property (nonatomic, readonly) NSString *pinpadHardwareRevision;
@property (readonly) BOOL pinpadSimulatorMode;
@property (readonly) int pinpadResponse;
@property (readonly) NSString* frameworkVersion;
@property (readonly) int ackTimeout;
@property (readonly) int frameworkTimeout;
@property (readonly) int ioTimer;
@property (readonly) int PINTimeout;
@property (readonly) int accountEntryTimeout;
@property (readonly) int continueTransactionTimeout;
@property (readonly) BOOL pinpadConnected;
@property (readonly) BOOL connected;
@property (readonly) BOOL BTconnected;
@property (readonly) BOOL initialized;
@property (readonly) BOOL timeoutReached;
@property (readonly) BOOL willWaitForResponse;
@property(nonatomic, retain) VFIZontalk *zonTalk;
@property (nonatomic, retain) NSRunLoop *theRL;


@property (nonatomic, readonly) NSString *keyLoadErrorCode;





@end


