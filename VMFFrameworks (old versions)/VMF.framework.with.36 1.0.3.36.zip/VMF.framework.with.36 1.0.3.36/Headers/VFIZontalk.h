//
//  VFIPayware.h
//  IDTech
//
//  Created by Randy Palermo on 5/4/10.
//  Copyright 2010 VeriFone, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import	<ExternalAccessory/ExternalAccessory.h>
#import "InitialBlock.h"
#import "StatusInformation.h"
#import "NSData-AES.h"
#import "Base64.h"
#import "VFI_EADSessionController.h"

@protocol VFIZontalkDelegate <NSObject>

@optional
- (void) zontalkLogEntry:(NSString*)logEntry withSeverity:(int)severity;



- (void) zontalkConnected:(BOOL)isConnected;
- (void) zontalkDataReceived:(NSData*)data;
- (void) zontalkDataSent:(NSData*)data;
- (void) zontalkDownloadStatus:(NSString*)log;
- (void) zontalkDownloadBlocks:(int)TotalBlocks sent:(int)BlocksSent;
@end







typedef enum {
	MessageTypes_Error = 0,
	MessageTypes_Information = 1,
	MessageTypes_Connecting = 2,
	MessageTypes_ConnectingUpdate = 3,
	MessageTypes_Connected = 4,
	MessageTypes_ConnectFailed = 5
} MessageTypes;


typedef enum {
	ReturnCodes_Success = 0,
	ReturnCodes_ConnectFailed = 1,
	ReturnCodes_RetriesExhausted = 2,
	ReturnCodes_TooManyNAKs = 3,
	ReturnCodes_TimeoutOccurred = 4,
	ReturnCodes_InvalidTerminalResponse = 5,
	ReturnCodes_SendFailed = 6,
	ReturnCodes_FileFormat = 7,
	ReturnCodes_FileNotFound = 8,
	ReturnCodes_FileIO = 9,
	ReturnCodes_System = 10
} ReturnCodes;










@class VFI_EADSessionController;

@interface VFIZontalk : NSObject <VFI_EADSessionControllerDelegate, EAAccessoryDelegate, NSStreamDelegate,UIApplicationDelegate> {
	
	id <VFIZontalkDelegate> delegate;
	EAAccessory *_accessory;
	VFI_EADSessionController *_eaSessionController;
	NSRunLoop *theRL;
	UIBackgroundTaskIdentifier bgTask;

}
+ (VFIZontalk *)sharedController;
-(void) ignoreDisconnect;
-(id)init;
-(void) initDevice:(NSNotification *)notification;
-(void) deviceDisconnected:(NSNotification *)notification;
-(void) deviceDisconnected2:(NSNotification *)notification;
-(void)deviceDisconnected3:(NSNotification *)notification;
-(void) initDevice;
-(void) initBridge;
-(void) closeDevice;
-(void) simulatorMode:(BOOL)activate;
-(void) processData:(NSMutableArray *)param binaryData:(NSMutableDictionary *)data;
-(void) displayMessage:(NSString*)msg;
-(int) sendStringCommand:(NSString*)cmd calcLRC:(BOOL)lrc;
-(int) sendDataCommand:(NSMutableData*)cmd calcLRC:(BOOL)lrc;
-(void) consoleEnabled:(BOOL)enable;
- (void)channelConnection:(NSString *)channelResponse;
-(NSString*) getLog;
-(NSString*) getLogFilename;
-(void) clearLog;
-(void) logEnabled:(BOOL)enable;
-(void)processReceivedData:(NSData*)data;
-(void) setCommunicationID:(NSString *)commID;
-(id) initWithCommunicationID:(NSString *) commID;
-(NSString*) frameworkVersion;
-(void)removeListeners;
-(void)deviceDisconnectedBridge:(NSNotification *)notification;
@property (retain) id delegate;

@property (nonatomic, readonly) NSString *zontalkName;
@property (nonatomic, readonly) NSString *zontalkManufacturer;
@property (nonatomic, readonly) NSString *zontalkModelNumber;
@property (nonatomic, readonly) NSString *zontalkSerialNumber;
@property (nonatomic, readonly) NSString *zontalkFirmwareRevision;
@property (nonatomic, readonly) NSString *zontalkHardwareRevision;
@property (readonly) BOOL zontalkSimulatorMode;
@property (readonly) BOOL zontalkConnected;
@property (readonly) BOOL connected;
@property (readonly) BOOL BTconnected;
@property (readonly) BOOL initialized;
@property (nonatomic, retain) NSRunLoop *theRL;




@end

