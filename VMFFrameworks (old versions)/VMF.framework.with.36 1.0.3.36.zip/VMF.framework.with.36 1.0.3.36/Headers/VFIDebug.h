//
//  VFIPayware.h
//  IDTech
//
//  Created by Randy Palermo on 5/4/10.
//  Copyright 2010 Verifone, Inc. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import	<ExternalAccessory/ExternalAccessory.h>
#import <UIKit/UIKit.h>
#import "VFI_EADSessionController.h"



@protocol VFIDebugDelegate <NSObject>

@optional
- (void) debugLogEntry:(NSString*)logEntry withSeverity:(int)severity;
- (void) debugInitialized:(BOOL)isInitialized;

- (void) debugReconnectStarted;
- (void) debugReconnectFinished;
- (void) debugConnected:(BOOL)isConnected;
- (void) debugDataReceived:(NSData*)data;
- (void) debugDataSent:(NSData*)data;
@end

@class VFI_EADSessionController;

@interface VFIDebug : NSObject <VFI_EADSessionControllerDelegate, EAAccessoryDelegate, NSStreamDelegate,UIApplicationDelegate> {
	
	id <VFIDebugDelegate> delegate;
	EAAccessory *_accessory;
	VFI_EADSessionController *_eaSessionController;
	UIBackgroundTaskIdentifier bgTask;
}

-(id)init;
+ (VFIDebug *)sharedController;
-(void) initDevice:(NSNotification *)notification;
-(void) deviceDisconnected3:(NSNotification *)notification;
-(void) initDevice;
-(void) initBridge;
-(void)deviceDisconnectedBridge:(NSNotification *)notification;
-(void) closeDevice;
- (void)sendString:(NSString*)string;
- (void)sendData:(NSData*)data;
- (void) sendBuf:(const uint8_t *)buf size:(int)len;
- (void)channelConnection:(NSString *)channelResponse;
-(NSString*) frameworkVersion;
-(NSString*) getLog;
-(NSString*) getLogFilename;
-(void) clearLog;
-(void) logEnabled:(BOOL)enable;
-(void)processReceivedData:(NSData*)data;

@property (retain) id delegate;
@property (nonatomic, readonly) NSString *debugName;
@property (nonatomic, readonly) NSString *debugManufacturer;
@property (nonatomic, readonly) NSString *debugModelNumber;
@property (nonatomic, readonly) NSString *debugSerialNumber;
@property (nonatomic, readonly) NSString *debugFirmwareRevision;
@property (nonatomic, readonly) NSString *debugHardwareRevision;

@property (readonly) BOOL debugConnected;
@property (readonly) BOOL connected;
@property (readonly) BOOL BTconnected;


@property (readonly) BOOL initialized;




@end