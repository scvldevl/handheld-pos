//
//  VFICardData.h
//  Merchant
//
//  Created by Randy Palermo on 9/7/10.
//

#import <Foundation/Foundation.h>

@class VFICardData;

//VFICardData *_VFICardData;

@interface VFICardData : NSObject {
	NSString *AID;
	NSString *appPreferredName;
	NSString *appLabel;
	int serviceCode;
	NSString *cardHolderName;
	NSData *track2;
	NSData *track1;
	NSData *track3;
	NSString *accountNumber;
	NSString *expiryDate;
	NSMutableDictionary *emvTags;
	BOOL isCTLS;
	int entryType;

}

-(void)clear;



@property (nonatomic, retain) NSString *AID;
@property (nonatomic, retain) NSString *appPreferredName;
@property (nonatomic, retain) NSString *appLabel;
@property int serviceCode;
@property int entryType;
@property (nonatomic, retain) NSString *cardHolderName;
@property (nonatomic, retain) NSData *track2;
@property (nonatomic, retain) NSData *track1;
@property (nonatomic, retain) NSData *track3;
@property (nonatomic, retain) NSString *accountNumber;
@property (nonatomic, retain) NSString *expiryDate;
@property BOOL isCTLS;
@property (nonatomic, retain) NSMutableDictionary *emvTags;

@end
