//
//  VFIEMVAuthorization.h
//  VMF
//
//  Created by Randy Palermo on 9/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@class VFIEMVAuthorization;

@interface VFIEMVAuthorization : NSObject {
	NSMutableDictionary* emvTags;
	int pinSuccessful;
}

-(void)clear;
-(id)init;

@property (nonatomic, retain) NSMutableDictionary* emvTags;
@property int pinSuccessful;

@end
