//
//  VFIEMVConfiguration.h
//  VMF
//
//  Created by Randy Palermo on 9/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class VFIEMVConfiguration;

@interface VFIEMVConfiguration : NSObject {
	short schemeReference;
	short issuerReference;
	short trmDataPresent;
	short targetRSPercent;
	long floorLimit;
	long rsThreshold;
	short maxTargetRSPercent;
	short merchantForceOnlineFlag;
	short blackListCardSupportFlag;
	short fallbackAllowedFlag;
	NSString *tacDefault;
	NSString *tacDenial;
	NSString *tacOnline;
	NSString *defaultTDOL;
	NSString *defaultDDOL;
	short nextRecord;
	short autoSelectApplication;
	NSString *countryCode;
	NSString *currencyCode;
	NSString *terminalCapacity;
	NSString *additionalCapacity;
	NSString *terminalType;
	NSString *merchantCategoryCode;
	NSString *terminalCategoryCode;
	NSString *terminalID;
	NSString *merchantID;
	NSString *acquireID;
	NSString *capkIndex;
	NSString *pinBypassFlag;
	NSString *pinTimeout;
	NSString *pinFormat;
	NSString *pinScriptNumber;
	NSString *pinMacroNumber;
	NSString *pinDevriKey;
	NSString *pinDevriMacro;
	NSString *cardStatusDisplay;
	short termCurExp;
	short issAcqFlag;
	short noDisplaySupportFlag;
	short modifyCandidateListFlag;
	NSString *rfu1String;
	NSString *rfu2String;
	NSString *rfu3String;
	short rfu1;
	short rfu2;
	short rfu3;
}

-(void)clear;



@property short schemeReference;
@property short issuerReference;
@property short trmDataPresent;
@property short targetRSPercent;
@property long floorLimit;
@property long rsThreshold;
@property short maxTargetRSPercent;
@property short merchantForceOnlineFlag;
@property short blackListCardSupportFlag;
@property short fallbackAllowedFlag;
@property (nonatomic, retain) NSString *tacDefault;
@property (nonatomic, retain) NSString *tacDenial;
@property (nonatomic, retain) NSString *tacOnline;
@property (nonatomic, retain) NSString *defaultTDOL;
@property (nonatomic, retain) NSString *defaultDDOL;
@property short nextRecord;
@property short autoSelectApplication;
@property (nonatomic, retain) NSString *countryCode;
@property (nonatomic, retain) NSString *currencyCode;
@property (nonatomic, retain) NSString *terminalCapacity;
@property (nonatomic, retain) NSString *additionalCapacity;
@property (nonatomic, retain) NSString *terminalType;
@property (nonatomic, retain) NSString *merchantCategoryCode;
@property (nonatomic, retain) NSString *terminalCategoryCode;
@property (nonatomic, retain) NSString *terminalID;
@property (nonatomic, retain) NSString *merchantID;
@property (nonatomic, retain) NSString *acquireID;
@property (nonatomic, retain) NSString *capkIndex;
@property (nonatomic, retain) NSString *pinBypassFlag;
@property (nonatomic, retain) NSString *pinTimeout;
@property (nonatomic, retain) NSString *pinFormat;
@property (nonatomic, retain) NSString *pinScriptNumber;
@property (nonatomic, retain) NSString *pinMacroNumber;
@property (nonatomic, retain) NSString *pinDevriKey;
@property (nonatomic, retain) NSString *pinDevriMacro;
@property (nonatomic, retain) NSString *cardStatusDisplay;
@property short termCurExp;
@property short issAcqFlag;
@property short noDisplaySupportFlag;
@property short modifyCandidateListFlag;
@property (nonatomic, retain) NSString *rfu1String;
@property (nonatomic, retain) NSString *rfu2String;
@property (nonatomic, retain) NSString *rfu3String;
@property short rfu1;
@property short rfu2;
@property short rfu3;



@end
