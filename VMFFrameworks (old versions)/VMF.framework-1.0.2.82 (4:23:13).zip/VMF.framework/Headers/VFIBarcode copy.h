//
//  VFIPayware.h
//  IDTech
//
//  Created by Randy Palermo on 5/4/10.
//  Copyright 2010 Rapadev, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import	<ExternalAccessory/ExternalAccessory.h>


typedef enum {
    barcodeScanModeContinuous	= 0,
    barcodeScanModeLevel		= 1,	
    barcodeScanModePulse		= 2,
	barcodeScanModeFlashing		= 3,
	barcodeScanModeAutoStand	= 4,
} barcodeScanMode;




@protocol VFIBarcodeDelegate <NSObject>



@required
- (void) barcodeConnected:(BOOL)isConnected;
- (void) barcodeDataReceived:(NSData*)data;
- (void) barcodeDataSent:(NSData*)data;
- (void) barcodeScanFailed:(int)code;
- (void) barcodeScanData:(NSData*)data;
@end

@interface VFIBarcode : NSObject <EAAccessoryDelegate> {
	
	id <VFIBarcodeDelegate> delegate;
	NSStream *os;	
	NSMutableArray* cmdArray;
}

-(void) initDevice;
-(int) sendStringCommand:(NSString*)cmd calcLRC:(BOOL)lrc;
-(int) sendDataCommand:(NSData*)data calcLRC:(BOOL)lrc;
-(void) simulatorMode:(BOOL)activate;
-(void) sendAbort;
-(void) sendACK;
-(void) sendNAK;


-(void) startBarcodeScanner;
-(void) stopBarcodeScanner;

-(void) setGoodReadLED:(BOOL)isOn;
-(void) setBeepSequence:(int)mode;
-(void) barcodeSleep;
-(void) barcodeReset;
-(void) barcodeResetFactoryDefaults;



-(void) configureBarcode:(barcodeScanMode)mode timeout:(int)seconds hardwareTrigger:(BOOL)enabled;
-(void) configureAimingBeam:(int)mode duration:(int)milliseconds;
-(void) turnOffAfterGoodRead:(BOOL)enable;
-(void) powerHold:(BOOL)enable;


-(void) consecutiveReads:(int)value timeoutIdenticalReads:(int)toIdentical timeoutDifferentReads:(int)toDifferent;

-(void) beepTone:(int)Hz volume1thru3:(int)volume;
-(void) beepActive:(BOOL)onPowerUp error:(BOOL)onError setup:(BOOL)onSetup;
-(void) beepGoodRead:(int)numberOfBeeps beepDuration:(int)beepMilliseconds ledDuration:(int)ledMilliseconds;






-(void) codabarActive:(BOOL)enable;
-(void) codabarStartStop:(int)mode;
-(void) codabarCLSI:(BOOL)enable;
-(void) codabarCodeMark:(char)ascii;
-(void) codabarCheckDigit:(BOOL)verify  transmit:(BOOL)transmit;
-(void) codabarLength:(int)mode length1:(int)l1 length2:(int)l2 length3:(int)l3;

-(void) codablockActive:(BOOL)enableF enableA:(BOOL)enableA;
-(void) codablockCodeMark:(char)asciiF asciiA:(char)asciiA;

-(void) code11Active:(BOOL)enable;
-(void) code11CodeMark:(char)ascii;
-(void) code11CheckDigit:(BOOL)verify  transmit:(BOOL)transmit;
-(void) code11Length:(int)mode length1:(int)l1 length2:(int)l2 length3:(int)l3;

-(void) code39Active:(BOOL)enable  fullAsciiConversion:(BOOL)enableAC useExtendedReadingRange:(BOOL)enableER startStop:(BOOL)startStop acceptedStartCharacter:(int)code;
-(void) code39CodeMark:(char)ascii;
-(void) code39CheckDigit:(BOOL)verify  transmit:(BOOL)transmit;
-(void) code39Length:(int)mode length1:(int)l1 length2:(int)l2 length3:(int)l3;

-(void) code93Active:(BOOL)enable;
-(void) code93CodeMark:(char)ascii;
-(void) code93Length:(int)mode length1:(int)l1 length2:(int)l2 length3:(int)l3;

-(void) code128Active:(BOOL)enable useEAN128Identifier:(BOOL)enable128 FNC1conversion:(char)fnc;
-(void) code128ISBT:(BOOL)enable transmission:(int)code concatenateAnyPair:(BOOL)enableP;
-(void) code128CheckDigit:(BOOL)verify;
-(void) code128CodeMark:(char)ascii;
-(void) code128Length:(int)mode length1:(int)l1 length2:(int)l2 length3:(int)l3;

-(void) interleaved2of5Active:(BOOL)enable;
-(void) interleaved2of5CodeMark:(char)ascii;
-(void) interleaved2of5CheckDigit:(int)mode  transmit:(BOOL)transmit;
-(void) interleaved2of5Length:(int)mode length1:(int)l1 length2:(int)l2 length3:(int)l3;

-(void) matrix2of5Active:(BOOL)enable;
-(void) matrix2of5CodeMark:(char)ascii;
-(void) matrix2of5CheckDigit:(BOOL)useModulo10  transmit:(BOOL)transmit;
-(void) matrix2of5Length:(int)mode length1:(int)l1 length2:(int)l2 length3:(int)l3;

-(void) msiCodeActive:(BOOL)enable;
-(void) msiCodeCodeMark:(char)ascii;
-(void) msiCodeCheckDigit:(BOOL)useDoubleModulo10  transmit:(BOOL)transmit;
-(void) msiCodeLength:(int)mode length1:(int)l1 length2:(int)l2 length3:(int)l3;



-(void) plessyCodeActive:(BOOL)enable;
-(void) plessyCodeCodeMark:(char)ascii;
-(void) plessyCodeCheckDigit:(BOOL)enable;
-(void) plessyCodeLength:(int)mode length1:(int)l1 length2:(int)l2 length3:(int)l3;

-(void) standard2of5Active:(BOOL)enable format:(BOOL)use4startstopbars;
-(void) standard2of5CodeCodeMark:(char)ascii;
-(void) standard2of5CheckDigit:(BOOL)useModulo  transmit:(BOOL)transmit;
-(void) standard2of5Length:(int)mode length1:(int)l1 length2:(int)l2 length3:(int)l3;

-(void) telepenActive:(BOOL)enable format:(BOOL)useNumeric;
-(void) telepenCodeCodeMark:(char)ascii;
-(void) telepenCodeLength:(int)mode length1:(int)l1 length2:(int)l2 length3:(int)l3;

-(void) upcAActive:(BOOL)enable;
-(void) upcACheckDigit:(BOOL)checkDigit transmitNumberSystem:(BOOL)numberSystem;
-(void) upcACodeMark:(char)ascii;

-(void) upcEActive:(BOOL)enable;
-(void) upcECheckDigit:(BOOL)checkDigit transmitNumberSystem:(BOOL)numberSystem;
-(void) upcECodeMark:(char)ascii;

-(void) ean8Active:(BOOL)enable;
-(void) ean8CodeMark:(char)ascii;
-(void) ean8CheckDigit:(BOOL)checkDigit;


-(void) ean13Active:(BOOL)enable;
-(void) ean13CodeMark:(char)ascii;
-(void) ean13CheckDigit:(BOOL)checkDigit;

-(void) isbnConvertEan13Active:(BOOL)enable;

-(void) ean8TransmitAsEan13:(BOOL)enable;
-(void) upcETransmitAsUPCA:(BOOL)enable;
-(void) upcATransmitAsEan13:(BOOL)enable;

-(void) upc_eanAddOnDigits:(BOOL)enable;
-(void) upc_eanAddOn2:(BOOL)enable;
-(void) upc_eanAddOn5:(BOOL)enable;














@property (retain) id delegate;
@property (nonatomic, retain) NSStream	*os;
@property (nonatomic, retain) NSMutableArray	*cmdArray;

@property (nonatomic, readonly) NSString *barcodeName;
@property (nonatomic, readonly) NSString *barcodeManufacturer;
@property (nonatomic, readonly) NSString *barcodeModelNumber;
@property (nonatomic, readonly) NSString *barcodeSerialNumber;
@property (nonatomic, readonly) NSString *barcodeFirmwareRevision;
@property (nonatomic, readonly) NSString *barcodeHardwareRevision;
@property (readonly) BOOL barcodeSimulatorMode;
@property (readonly) BOOL barcodeConnected;





@end

