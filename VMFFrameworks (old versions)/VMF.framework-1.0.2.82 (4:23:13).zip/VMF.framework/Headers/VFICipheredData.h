//
//  VFICipheredData.h
//  VMF
//
//  Created by Randy Palermo on 1/25/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface VFICipheredData : NSObject {


	int encryptionType;
	NSString* keyID;
	int dataType;
	NSString* encryptedBlob_1;
	NSString* encryptedBlob_2;

}

-(void)clear;


@property int encryptionType;
@property (nonatomic, retain) NSString* keyID;
@property int dataType;
@property (nonatomic, retain) NSString* encryptedBlob_1;
@property (nonatomic, retain) NSString* encryptedBlob_2;


@end
