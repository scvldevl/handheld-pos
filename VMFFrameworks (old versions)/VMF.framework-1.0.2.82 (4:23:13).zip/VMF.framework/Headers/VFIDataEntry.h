//
//  VFIDataEntry.h
//  VMF
//
//  Created by Randy Palermo on 9/9/10.
//  Copyright 2010 Rapadev, LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

@class VFIDataEntry;

@interface VFIDataEntry : NSObject {
	float tipAmount;
	float cashbackAmount;
	int surchargeIndicator;
	NSString* serialNumber;
	int amountConfirmed;
	int accountSelected;
	NSData* pinBlock;
	int cashBackSelected;
	int tipSelected;
}

-(void)clear;

@property float tipAmount;
@property float cashbackAmount;
@property int surchargeIndicator;
@property (nonatomic, retain) NSString* serialNumber;
@property int amountConfirmed;
@property int accountSelected;
@property (nonatomic, retain) NSData* pinBlock;
@property int cashBackSelected;
@property int tipSelected;

@end
