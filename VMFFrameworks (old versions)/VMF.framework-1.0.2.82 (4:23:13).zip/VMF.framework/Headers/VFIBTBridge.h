//
//  VFIBTBridge.h
//  VMF
//
//  Created by Randy Palermo on 6/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import	<ExternalAccessory/ExternalAccessory.h>
#import "VFIPinpad.h"
#import "VFIControl.h"
#import "VFIBarcode.h"
#import "VFIZontalk.h"
#import "VFI_EADSessionController.h"


@protocol VFIBTBridgeDelegate <NSObject>

@optional

- (void) btbridgeDataReceived:(NSData*)data;
- (void) btbridgeDataSent:(NSData*)data;

@end



@class VFI_EADSessionControllery;


@interface VFIBTBridge : NSObject <EAAccessoryDelegate, NSStreamDelegate>{
	id <VFIBTBridgeDelegate> delegate;
	EAAccessory *_accessory;
	VFI_EADSessionControllery *_eaSessionController;
	NSMutableData *pinpadMD;
	NSMutableData *controlMD;
	NSMutableData *barcodeMD;
	NSMutableData *zontalkMD;
	NSMutableData *debugMD;
	
	
}
+(void) disableBTBridge;
+(BOOL) disabledBTBridge;
+(VFIBTBridge*) getBTBridge;


-(void) setPinPadInit:(BOOL)init;
-(void) setBarcodeInit:(BOOL)init;
-(void) setControlInit:(BOOL)init;
-(void) setZontalkInit:(BOOL)init;
-(BOOL) initReady;
-(id)init;
-(void) setCommunicationID:(NSString *)commID;
-(id) initWithCommunicationID:(NSString *) commID;
-(void) initPinpad:(VFIPinpad*)del;
-(void) initZontalk:(VFIZontalk*)del;
-(void) initControl:(VFIControl*)del;
-(void) initBarcode:(VFIBarcode*)del;
-(void) initDebug;
-(void) pinpadData:(NSData*)data;
-(void) controlData:(NSData*)data;
-(void) barcodeData:(NSData*)data;
-(void) zontalkData:(NSData*)data;
-(void) debugData:(NSData*)data;
- (void)sendString:(NSString*)string;
- (void)sendData:(NSData*)data;
-(void) sendDataToChannel:(NSData*)data channel:(int)channel;
-(void)deviceDisconnected:(NSNotification *)notification;
-(void)deviceDisconnected2:(NSNotification *)notification;
-(void) setPinPadDelegate:(VFIPinpad*)del;
-(void) setBarcodeDelegate:(VFIBarcode*)del;
-(void) setZontalkDelegate:(VFIZontalk*)del;
-(void) setControlDelegate:(VFIControl*)del;
@property (retain) id delegate;

@property (nonatomic, retain) NSMutableData *pinpadMD;
@property (nonatomic, retain) NSMutableData *controlMD;
@property (nonatomic, retain) NSMutableData *barcodeMD;
@property (nonatomic, retain) NSMutableData *zontalkMD;
@property (nonatomic, retain) NSMutableData *debugMD;
@property (readonly) BOOL connected;

@end
