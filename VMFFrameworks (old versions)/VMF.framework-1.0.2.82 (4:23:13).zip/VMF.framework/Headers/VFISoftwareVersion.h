//
//  VFISoftwareVersion.h
//  VMF
//
//  Created by Randy Palermo on 11/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface VFISoftwareVersion : NSObject {
	NSString *AppMajor;
	NSString *AppMinor;
	NSString *AppBuild;
	NSString *OSPlatform;
	NSString *OSID;
	NSString *OSVersion;
	NSString *OSSubVersion;
	
	
}

-(void)clear;



@property (nonatomic, retain) NSString *AppMajor;
@property (nonatomic, retain) NSString *AppMinor;
@property (nonatomic, retain) NSString *AppBuild;
@property (nonatomic, retain) NSString *OSPlatform;
@property (nonatomic, retain) NSString *OSID;
@property (nonatomic, retain) NSString *OSVersion;
@property (nonatomic, retain) NSString *OSSubVersion;

@end



