//
//  ISCP_HIGH.h
//  VMF
//
//  Created by Randy Palermo on 10/5/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ISCP_HIGH; 

@interface ISCP_HIGH : NSObject {
    unsigned char commandType;                    // Type of command
	unsigned char group;                // setup/control/status/event
	unsigned char fid;                  // frame ID
	NSData* param;	
	
}

-(void)clear;

@property unsigned char commandType;
@property unsigned char group;
@property unsigned char fid;
@property (nonatomic, retain) NSData *param;



@end
