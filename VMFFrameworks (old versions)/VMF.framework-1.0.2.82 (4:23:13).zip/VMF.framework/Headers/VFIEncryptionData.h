//
//  VFIEncryptionData.h
//  VMF
//
//  Created by Randy Palermo on 9/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class VFIEncryptionData;

@interface VFIEncryptionData : NSObject {

	NSData *macBlock;
	NSData *pinBlock;
	NSString *pinBlockStr;
	NSString *serialNumber;
	int accountSelection;
}


-(void)clear;
-(id)init;

@property (nonatomic, retain) NSData *macBlock;
@property (nonatomic, retain) NSData *pinBlock;
@property (nonatomic, retain) NSString *pinBlockStr;
@property (nonatomic, retain) NSString *serialNumber;
@property int accountSelection;

@end
