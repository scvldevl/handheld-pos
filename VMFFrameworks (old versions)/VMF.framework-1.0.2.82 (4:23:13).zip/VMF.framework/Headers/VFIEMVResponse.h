//
//  VFIEMVResponse.h
//  VMF
//
//  Created by Randy Palermo on 9/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class VFIEMVResponse;

@interface VFIEMVResponse : NSObject {

	NSData *macBlock;
	NSData *tpkKey;
	NSData *takKey;
	NSData *macData;
	int hostDecision;
	BOOL displayResult;
	NSData *hostTagString;
	int scriptId;
	BOOL clearBeforeScriptWrite;
	int numberOfScripts;
	int scriptLength;
	NSData *scriptData;
}


-(void)clear;

@property (nonatomic, retain) NSData *macBlock;
@property (nonatomic, retain) NSData *tpkKey;
@property (nonatomic, retain) NSData *takKey;
@property (nonatomic, retain) NSData *macData;
@property int hostDecision;
@property BOOL displayResult;
@property (nonatomic, retain) NSData *hostTagString;
@property int scriptId;
@property BOOL clearBeforeScriptWrite;
@property int numberOfScripts;
@property int scriptLength;
@property (nonatomic, retain) NSData *scriptData;



@end
