//
//  VFIPayware.h
//  IDTech
//
//  Created by Randy Palermo on 5/4/10.
//  Copyright 2010 Rapadev, LLC. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import	<ExternalAccessory/ExternalAccessory.h>
#import "ISCP_HIGH.h"
#import <UIKit/UIKit.h>

#define _barcodeFMVersion  @"1.0.0.13";


/** Beeper command defintions **/
typedef struct _T_BEEP {
    int freq;
    int dur;
}T_BEEP;

typedef struct _T_BEEP_DEF{
    T_BEEP b1;
    int bPause;
    T_BEEP b2;
}T_BEEP_DEF;

/** Barcode Scanner High Level Command structure **/
/** This Structure is the parameter field for BCS ISCP host command **/
// ISCP Frame Types from host
#define TYPE_SETUP_READ 0x40
#define TYPE_SETUP_WRITE 0x41
#define TYPE_CONTROL 0x42
#define TYPE_STATUS_READ 0x43
#define TYPE_PERMISSION_READ 0x44
#define TYPE_PERMISSION_WRITE 0x45

// ISCP Frame Types from Scanner
#define TYPE_SETUP_REPLY 0x50
#define TYPE_RESULT 0x51
#define TYPE_STATUS_REPLY 0x53
#define TYPE_SETUP_PERMISSION_REPLY 0x54
#define TYPE_BARCODE_DATA 0x60
#define TYPE_EVENT_NOTIFICATION 0x61
#define TYPE_SETUP_BARCODE_DATA 0x62



// Barcode Types
enum  {
	BC_EAN_UPC2 ='X', 
	BC_EAN_UPC1 ='E', 
	BC_CODABAR ='F', 
	BC_CODABLOCK ='O', 
	BC_CODE11 ='H', 
	BC_CODE39 ='A', 
	BC_CODE93 ='G', 
	BC_CODE128 ='C', 
	BC_DATAMATRIX ='d', 
	BC_GS1 ='e', 
	BC_INTERLEAVED_2_OF_5 ='I', 
	BC_MAXICODE ='U', 
	BC_MSICODE ='M', 
	BC_PDF417 ='L', 
	BC_PLESSYCODE ='P', 
	BC_QRCODE ='Q', 
	BC_STAN_2_OF_5_2BARS ='R', 
	BC_STAN_2_OF_5_3BARS ='S', 
	BC_TELEPEN ='B'  
};




/** Communciations between Host and Verix BCS Application **/
// HOST Commands
enum {
    BCS_START_SCAN=0,                       // Powers on and enales scanner (required to send commands)
    BCS_ABORT_SCAN,                         // disable and power down scanner
    BCS_ISCP_PACKET,                        // Frame send to Barcode Scanner
    BCS_CONFIGURE_BEEP,                     // Configures beep for successful scan
    BCS_SCAN_TIMEOUT,                       // Set time in MS scanner stays on waiting for successful scan
    BCS_RAW_SCAN_DATA,                      // PayWare terminal initiated.  No response from Host.
    BCS_APPLICATION_VERSION,                // returns the version of the Barcode Application
    BCS_TRIGGER_MODE,                       // Button Trigger mode: 0 = Edge  1 = Level
    BCS_BEEP_IMMEDIATE,                     // Beep on demand
    BCS_GET_BEEP_CONFIG,                    // Retrieve current beep configuration
    BCS_BUTTON_STATUS,                      // Retreive current button position
    BCS_SOFT_TRIGGER                        // Control Scanner Trigger in "SOFT" or "PASSIVE" trigger mode};
	
} ;

enum  {
	COMM_RESULT_ACK=0,
	COMM_RESULT_NAK,
	COMM_RESULT_BUSY,
	COMM_RESULT_BAD_RESPONSE,
	COMM_RESULT_NO_RESPONSE
	
} ;

// Barcode Trigger Button Presses
enum  {
    BCS_TRIGGER_RELEASED = 0,
    BCS_TRIGGER_LEFT_PRESSED,
    BCS_TRIGGER_RIGHT_PRESSED
} ;


// Barcode Trigger Button Modes
enum {
    BCS_BUTTON_EDGE = 0,
    BCS_BUTTON_LEVEL,
    BCS_BUTTON_SOFT,
    BCS_BUTTON_PASSIVE
};



// Low Level Frame
#define LOW_ACK         0x0200060003      
#define LOW_NAK         0x0200150003
#define LOW_BUSY        0x02001B0003
#define LOW_RESEND      0x0200050003




@protocol VFIBarcodeDelegate <NSObject>

@optional
- (void) commandResult:(int)result;
- (void) barcodeTriggerEvent:(int)BCS_TRIGGER;
- (void) barcodeLogEntry:(NSString*)logEntry withSeverity:(int)severity;
- (void) barcodeSerialData:(NSData*)data  incoming:(BOOL)isIncoming;
- (void) barcodeInitialized:(BOOL)isInitialized;


- (void) barcodeConnected:(BOOL)isConnected;
- (void) barcodeDataReceived:(NSData*)data;
- (void) barcodeDataSent:(NSData*)data;
- (void) barcodeScanData:(NSData*)data barcodeType:(int)thetype;




@end

@class VFI_EADSessionController;

@interface VFIBarcode : NSObject <EAAccessoryDelegate,NSStreamDelegate,UIApplicationDelegate> {
	
	id <VFIBarcodeDelegate> delegate;
	EAAccessory *_accessory;
	VFI_EADSessionController *_eaSessionController;
	
	NSRunLoop *theRL;
	
}

-(id)init;
-(void) initDevice:(NSNotification *)notification;
-(void) initDevice;
-(void) initBridge;;
-(void) initDeviceBackgroundAware:(UIApplication *)application;
-(void) startScan;
-(void) abortScan;
-(void) sendISCP:(ISCP_HIGH*)frame;
-(void) configureBeep:(T_BEEP_DEF)beep;
-(void) sendBeep:(T_BEEP_DEF)beep;
-(void) setBeep:(T_BEEP_DEF)beep;
-(void) setBeepOff;
-(void) setBeepOn;
-(void) setScanTimeout:(long)milliseconds;
-(void) setScanner2D;
-(void) setScanner1D;
-(void) setMultiScan;
-(void) setSingleScan;
-(void) sendHexString:(NSString*)string;
-(void) getVersion;
-(T_BEEP_DEF) getBeep;
-(void) setLevel;
-(void) setEdge;
-(void) setSoft;
-(void) setPassive;
-(NSString*) getLog;
-(NSString*) getLogFilename;
-(void) clearLog;
-(void) logEnabled:(BOOL)enable;
-(void) ignoreDuplicates:(BOOL)enable;
-(void) clearDuplicatesBuffer;
-(void) clearCommandBuffer;
-(void) consoleEnabled:(BOOL)enable;
-(void) sendTriggerEvent:(BOOL)activate;
-(void) barcodeTypeEnabled:(BOOL)enable;
-(void) resetScannerToFactoryDefaults;
-(void) setScanButtonMode:(BOOL)enable;
-(BOOL) getScanButtonMode;
-(NSString*) frameworkVersion;

-(void) includeAllBarcodeTypes;
-(void) includeBarcodeType:(int)type;
-(void) excludeBarcodeType:(int)type;

-(void) beepOnParsedScan:(BOOL)enable;
-(void) restartLoopDelay:(float)sec;
-(void) releaseOnDisconnect:(BOOL)release;
-(void) enableSoftTrigger:(BOOL)enable;
-(void) closeDevice;

-(void)processReceivedData:(NSData*)data;

- (void)channelConnection:(NSString *)channelResponse;
-(void) setCommunicationID:(NSString *)commID;
-(id) initWithCommunicationID:(NSString *) commID;







@property (retain) id delegate;


@property (nonatomic, readonly) NSString *barcodeName;
@property (nonatomic, readonly) NSString *barcodeManufacturer;
@property (nonatomic, readonly) NSString *barcodeModelNumber;
@property (nonatomic, readonly) NSString *barcodeSerialNumber;
@property (nonatomic, readonly) NSString *barcodeFirmwareRevision;
@property (nonatomic, readonly) NSString *barcodeHardwareRevision;
@property (nonatomic, readonly) NSString *barcodeVersion;
@property (readonly) BOOL barcodeConnected;
@property (readonly) BOOL connected;
@property (readonly) BOOL BTconnected;

@property (readonly) BOOL initialized;
@property (nonatomic, retain) NSRunLoop *theRL;







@end

