//
//  VFIPayware.h
//  IDTech
//
//  Created by Randy Palermo on 5/4/10.
//  Copyright 2010 Rapadev, LLC. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import	<ExternalAccessory/ExternalAccessory.h>
#import <UIKit/UIKit.h>



@protocol VFIDebugDelegate <NSObject>

@optional
- (void) debugInitialized:(BOOL)isInitialized;

@required
- (void) debugConnected:(BOOL)isConnected;
- (void) debugDataReceived:(NSData*)data;
- (void) debugDataSent:(NSData*)data;
@end

@class VFI_EADSessionController;

@interface VFIDebug : NSObject <EAAccessoryDelegate,NSStreamDelegate,UIApplicationDelegate> {
	
	id <VFIDebugDelegate> delegate;
	EAAccessory *_accessory;
	VFI_EADSessionController *_eaSessionController;
	NSRunLoop *theRL;
}

-(id)init;
-(void) initDevice:(NSNotification *)notification;
-(void) initDevice;
-(void) initDeviceBackgroundAware:(UIApplication *)application;
-(void) closeDevice;
-(void) sendCommand:(NSString*)cmd;
-(void) sendCommandLRC:(NSString*)cmd;
-(void) simulatorMode:(BOOL)activate;
-(void) consoleEnabled:(BOOL)enable;
-(void)processReceivedData:(NSData*)data;
-(NSString*) frameworkVersion;

@property (retain) id delegate;

@property (nonatomic, readonly) NSString *debugName;
@property (nonatomic, readonly) NSString *debugManufacturer;
@property (nonatomic, readonly) NSString *debugModelNumber;
@property (nonatomic, readonly) NSString *debugSerialNumber;
@property (nonatomic, readonly) NSString *debugFirmwareRevision;
@property (nonatomic, readonly) NSString *debugHardwareRevision;
@property (readonly) BOOL debugSimulatorMode;
@property (readonly) BOOL debugConnected;
@property (readonly) BOOL connected;
@property (readonly) BOOL initialized;
@property (readonly) BOOL BTconnected;
@property (nonatomic, retain) NSRunLoop *theRL;





@end

