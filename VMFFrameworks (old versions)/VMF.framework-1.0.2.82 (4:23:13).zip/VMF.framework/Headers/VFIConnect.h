//
//  VFIConnect.h
//  VMF
//
//  Created by Randy Palermo on 8/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <CoreLocation/CLLocationManagerDelegate.h>
#import "VFIaudioMSR.h"
#import "VFIPayware.h"
#import "VFI_XMLReader.h"
#import "VFIPinpad.h"
#import "DDASLLogger.h"
#import "DDAbstractDatabaseLogger.h"
#import "DDFileLogger.h"
#import "DDLog.h"
#import "DDTTYLogger.h"

#define KEYBITS		256
#define AESEncryptionErrorDescriptionKey	@"description"

typedef enum {
	HostAddress_Demo, 
	HostAddress_Production,
	HostAddress_Custom  
} HostAddress;



typedef enum {
	CardTypeNotRecognized,
	CardTypeVisa,
	CardTypeMC,
	CardTypeAmex,
	CardTypeDiscover,
	CardTypeDCIDisc,
	CardTypeJCBDisc,
	CardTypeEnRoute
} CardType;



typedef struct _allowedTransactions{
	BOOL		visa;
	BOOL		mc;
	BOOL		amex;
	BOOL		disc;
	BOOL		cbln;
	BOOL		jal;
	BOOL		jcb;
	BOOL		enrt;
	BOOL		dccb;
	BOOL		swch;
	BOOL		unkw;
	BOOL		all;
	BOOL		add_tip;
	BOOL		completion;
	BOOL		credit;
	BOOL		post_auth;
	BOOL		pre_auth;
	BOOL		signature;
	BOOL		sale;
	BOOL		voice_auth;
	BOOL		voiding;
} allowedTransactions;


typedef struct _swipeData {
	NSString*	maskedPAN;
	CardType	cardType;
	NSString*	firstName;
	NSString*	lastName;
} swipeData;

typedef struct _decryptedCredentials {
	NSString*	clientID;
	NSString*	deviceKey;
	NSString*	serialNumber;
	NSString*	deviceType;
} decryptedCredentials;

typedef enum {
	AccMessage_TrackDataReceived,
	AccMessage_ReaderTimeout,
	AccMessage_SledDisconnected,
	AccMessage_SledConnected,
	AccMessage_PinpadDisconnected,
	AccMessage_PinpadConnected,
	AccMessage_AudioMSRDisconnected,
	AccMessage_AudioMSRConnected,
	AccMessage_AudioMSRProcessing,
	AccMessage_AudioMSRWaitingForSwipe,
	AccMessage_AudioMSRTimeout,
	AccMessage_AudioMSRPoweringUp,
	AccMessage_UnableToReadTrack,
	AccMessage_VSPTrackCaptured,
	AccMessage_CardNotAccepted,
	AccMessage_ReaderNotReady,
	AccMessage_TrackCapturedForTransmission,
	AccMessage_SwipeTransmitTimeout,
	AccMessage_SwipeCancelled,
	AccMessage_KeepAliveDetected

	
} AccMessage;

typedef enum {
	VFIDevices_SecureAudioReader = 1,
	VFIDevices_VX600 = 2,
	VFIDevices_Sleeve = 4,
	VFIDevices_IDT = 8
	
} VFIDevices;


@protocol VFIConnectDelegate <NSObject>

@optional
- (void) accessoryDownloadStatus:(NSString*)log;
- (void) accessoryDownloadBlocks:(int)TotalBlocks sent:(int)BlocksSent;

@required
- (void) accessoryDataReceived:(AccMessage)message data:(swipeData)card;
@end


@interface VFIConnect : NSObject <NSXMLParserDelegate,VFIaudioMSRDelegate,VFIPaywareDelegate,CLLocationManagerDelegate,VFIPinpadDelegate>{
	
	
	id <VFIConnectDelegate> delegate;
	VFIPayware *gen1;
	VFIaudioMSR *uniReader;
	
}
-(void) setThreshold:(float)value;
-(id) initWithDelegate:(id)del;
-(id) initWithLogging:(id)del debugLogging:(BOOL)turnON toFile:(BOOL)logToDocFolder toTTY:(BOOL)logToXCodeTTY toConsole:(BOOL)logToConsoleApp;
-(id) initWithDelegate:(id)del devices:(VFIDevices)deviceFlags;
-(id) initWithLogging:(id)del debugLogging:(BOOL)turnON toFile:(BOOL)logToDocFolder toTTY:(BOOL)logToXCodeTTY toConsole:(BOOL)logToConsoleApp devices:(VFIDevices)deviceFlags;


-(void) close;
-(CardType) validateCardType:(NSString*)acct;///
-(NSString*) frameworkVersion;

-(NSDictionary*) submitTransaction:(NSDictionary*)values user:(NSString*)credentials error:(NSString**)errorText;///
-(NSString*) registerAccount:(NSString*)clientID userID:(NSString*)userID password:(NSString*)password gateway:(HostAddress)addr customIP:(NSString*)customIP;///
-(NSString*) registerAccountMultiUser:(NSString*)clientID userID:(NSString*)userID password:(NSString*)password gateway:(HostAddress)addr customIP:(NSString*)customIP;///
-(NSString*) registerAccount:(NSString*)clientID userID:(NSString*)userID password:(NSString*)password gateway:(HostAddress)addr customIP:(NSString*)customIP platform:(NSString*)type;///
-(NSString*) registerAccountMultiUser:(NSString*)clientID userID:(NSString*)userID password:(NSString*)password gateway:(HostAddress)addr customIP:(NSString*)customIP platform:(NSString*)type;///

-(NSString*) submitXML:(NSString*)xml user:(NSString*)credentials error:(NSString**)errorText;///
-(NSString*) convertImageBase64Jpeg:(UIImage*)image;///


-(void) logEntry:(NSString*)entry;
-(NSString*) resyncAccount:(NSString*)credentials;///

-(void) requestSwipe;
-(void) requestSwipeRepeating;
-(void) cancelSwipe;
-(void) setTimeout:(int)sec;


-(void) audioReaderContinuousPower:(BOOL)on;
-(void) audioReaderPromptForConnection:(BOOL)promptOn;

-(void)clearTrackData;

-(void) updateVX600:(NSData*)zipData;
- (void) updatePayware:(VFUpdateType)type fileData:(NSData*)data;

-(decryptedCredentials) decryptCredentials:(NSString*)credentials;
-(allowedTransactions) getAllowedTransactions:(NSString*)credentials;////
-(NSString*) getDeviceKey:(NSString*)credentials;///
-(NSString*) getClientID:(NSString*)credentials;///
-(NSString*) getCustomIP:(NSString*)credentials;///
-(HostAddress) getHostAddress:(NSString*)credentials;///
-(void) debugLogging:(BOOL)turnON toFile:(BOOL)logToDocFolder toTTY:(BOOL)logToXCodeTTY toConsole:(BOOL)logToConsoleApp;

@property (readonly) NSString* xmlResponse;////
@property (readonly) NSDictionary* dictResponse;////
@property (retain) id delegate;
@property (readonly) NSString* deviceSerialNumber;
@property (readonly) int track2Error;
@property (readonly) BOOL hasTrackData;
@property (readonly) BOOL gen1Connected;
@property (readonly) BOOL gen2Connected;
@property (nonatomic, retain) VFIPayware *gen1;
@property (nonatomic, retain) VFIPinpad *pinpad;
@property (nonatomic, retain) VFIaudioMSR *uniReader;

@property (readonly) int vfAudioJackMSRBatteryLevel;
@property (readonly) NSString* vfAudioJackMSRFirmware;
@property (readonly) NSString* encryptedTrackData;
@property (readonly) NSString* track1Data;
@property (readonly) NSString* activationTrack;

@property (readonly) NSString* SDKVersion;



@end
