//
//  VFIDiagnostics.h
//  VMF
//
//  Created by Randy Palermo on 9/9/10.
//  Copyright 2010 Rapadev, LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

@class VFIDiagnostics;

@interface VFIDiagnostics : NSObject {
	NSString *osversion;
	NSString *xpiVersion;
	NSString *vxciVersion;
	NSString *emvVersion;
	NSString *ctlsReaderFirmwareVersion;
	NSString *vspVersion;
	NSString *pinpadSerialNumber;
	

}

-(void)clear;



@property (nonatomic, retain) NSString *osversion;
@property (nonatomic, retain) NSString *xpiVersion;
@property (nonatomic, retain) NSString *vxciVersion;
@property (nonatomic, retain) NSString *emvVersion;
@property (nonatomic, retain) NSString *ctlsReaderFirmwareVersion;
@property (nonatomic, retain) NSString *vspVersion;
@property (nonatomic, retain) NSString *pinpadSerialNumber;

@end
