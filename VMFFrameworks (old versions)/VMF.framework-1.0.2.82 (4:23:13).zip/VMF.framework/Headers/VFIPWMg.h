//
//  VFIPWMg.h
//  VMF
//
//  Created by Randy Palermo on 7/22/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <VMF/VFIPWLm.h>

#define	VFIPMMSVersion @"1"

#define CARDVALIDATEREQUEST				@"CardPaymentServices/Validation"
#define CARDAUTHORIZEREQUEST			@"CardPaymentServices/Authorization"
#define CARDSAVEREQUEST						@"CardPaymentServices/Saving"
#define CASHCHECKAUTHORIZEREQUEST	@"CnChPaymentServices/Authorization"
#define CASHCHECKSAVEREQUEST			@"CnChPaymentServices/Saving"
#define	DEVACTIVATEREQUEST				@"RegistrationServices/Activation"
#define	DEVDEACTIVATEREQUEST			@"RegistrationServices/Deactivation"
#define	DEVCHANGEDEVKEYREQUEST		@"RegistrationServices/DeviceKey"
#define	DEVCONFIGREQUEST					@"RegistrationServices/DeviceConfig"
#define	CHANGEPASSWORDREQUEST					@"RegistrationServices/UserPassword"
#define	REPORTSUMMARYREQUEST			@"ReportingServices/DailySummary"
#define	REPORTTRANREQUEST					@"ReportingServices/Transactions"

/*
typedef enum {
	VFIPMTTSale						= 1,
	VFIPMTTRefund					= 2,
	VFIPMTTPreAuth				= 3,
	VFIPMTTRefundbyTRXID	= 4,
	VFIPMTTCancel					= 5,
	VFIPMTTComplete				= 6,
} VFIPMMSTranType;

typedef enum {
	VFIPMTECard		= 1,
	VFIPMTECash		= 2,
	VFIPMTECheque = 3,
} VFIPMMSTenderType;
*/

@interface VFIPWMg : NSObject <VFIPWLmDelegate>  {

	NSString* _primaryConnectString;
	NSString* _secondaryConnectString;
	NSString* _currentConnectString;
	BOOL secureFlag;
	BOOL testCertificationFlag;
	
	NSMutableData *responseData; // Only used for asynchronous calls to XML server
}


// Interface methods

- (id)init;
- (id)initWithConnectionStrings: (NSString*) primaryConnectString secondaryConnectString: (NSString*) secondaryConnectString;
- (int) processValidate:(VFICardDataEx*)cardData validateResult:(VFIValidationResult*)validateResult;
- (int) processAuthorize:(VFIAuthorizationEx*)authData authResult:(VFIAuthorizationResult*)authResult;
- (int) processComplete:(VFICompletionDataEx*)compData compResult:(VFICompleteResult*)compResult; 

- (int) activateDevice:(VFIAction) action userName:(NSString*)userName passWord:(NSString*)passWord 
		 deviceKey:(NSMutableString*)deviceKey merchantName:(NSMutableString*)merchantName connectdata:(VFIPMMSConnect*)connectData;
- (int) retrieveConfig:(VFIConfigurationDataRequest*)configDataRequest configData:(VFIConfigurationData*)configData connectdata:(VFIPMMSConnect*)connectData; 
- (int) retrieveReport:(VFIReportCriteria*)reportCriteria reportData:(VFIReportData*)reportData connectdata:(VFIPMMSConnect*)connectData;
- (int) retrieveSummary:(VFIReportSummary*)reportSummary connectdata:(VFIPMMSConnect*)connectData;
- (int) changePassword:(NSString*)userName oldPassword:(NSString*)oldPassword newPassword:(NSString*)newPassword connectdata:(VFIPMMSConnect*)connectData;
- (void) simulatorMode:(BOOL)activate;

// Implementation methods
- (int) processValidateInt:(VFICardDataEx*)cardData validateResult:(VFIValidationResult*)validateResult;
- (int) processAuthorizeCardInt:(VFIAuthorizationEx*)authData authResult:(VFIAuthorizationResult*)authResult;
- (int) processAuthorizeCashInt:(VFIAuthorizationEx*)authData authResult:(VFIAuthorizationResult*)authResult;
- (int) processSaveCardInt:(VFICompletionDataEx*)compDataEx compResult:(VFICompleteResult*)compResult; 
- (int) processSaveCashInt:(VFICompletionDataEx*)compDataEx compResult:(VFICompleteResult*)compResult; 
- (int) convertType:(VFITransType) type;
- (NSString*) nsdataToNSString:(NSData*)data;
- (NSString*) nsdataToNSStringWithSpace:(NSData*)data;
- (NSString*) VFIPMMSConnectToXMLString:(VFIPMMSConnect*)connectData action:(VFIAction)action userName:(NSString*)userName passWord:(NSString*)passWord error:(NSError**)error;
- (int) XMLDictionaryToVFIConfigurationData:(NSDictionary*)XMLData configData:(VFIConfigurationData*)configData;
- (NSString*) VFICardDataExToXMLString:(VFICardDataEx*)cardDataEx error:(NSError**)error;
- (int) XMLDictionaryToVFIValidationResult:(NSDictionary*)XMLData validateResult:(VFIValidationResult*)validateResult;
- (NSString*) VFIAuthorizationExCardToXMLString:(VFIAuthorizationEx*)authDataEx error:(NSError**)error;
- (int) XMLDictionaryToVFIAuthorizationResultCard:(NSDictionary*)XMLData authorizationResult:(VFIAuthorizationResult*)authorizationResult;
- (NSString*) VFIAuthorizationExCashToXMLString:(VFIAuthorizationEx*)authDataEx error:(NSError**)error;
- (NSString*) VFICompletionDataExCardToXMLString:(VFICompletionDataEx*)compDataEx error:(NSError**)error;
- (NSString*) VFICompletionDataExCashToXMLString:(VFICompletionDataEx*)compDataEx error:(NSError**)error;
- (NSString*) VFIReportCriteriaToXMLString:(VFIReportCriteria*)reportCriteria connectdata:(VFIPMMSConnect*)connectData error:(NSError**)error;
- (NSString*) VFIReportSummaryToXMLString:(VFIPMMSConnect*)connectData error:(NSError**)error;
- (NSString*) VFIChangePasswordToXMLString:(NSString*)userName oldPassword:(NSString*)oldPassword newPassword:(NSString*)newPassword connectData:(VFIPMMSConnect*)connectData error:(NSError**)error;
- (NSString*) VFIConfigurationDataRequestToXMLString:(VFIConfigurationDataRequest*)configurationDataRequest connectdata:(VFIPMMSConnect*)connectData error:(NSError**)error;

- (NSString*) ConvertNSDatetoXMLDateFormat:(NSDate*)date;
- (NSDate*) ConvertXMLDateFormattoNSDate:(NSString*)dateString timeZone:(NSString**)timeZone;

- (void) swapURL;
- (void) setSecureFlag:(BOOL)secure;
- (void) setTestCertificationFlag:(BOOL)testCertification;

- (NSString*)createReceiptData:(VFICompletionDataEx*)compDataEx;

// Interface properties
@property (readonly) BOOL pwmmSimulatorMode;

// Implementation properties
@property (nonatomic, readonly) NSString* _primaryConnectString;
@property (nonatomic, readonly) NSString* _secondaryConnectString;
@property (nonatomic, copy) NSString* _currentConnectString;

@end
