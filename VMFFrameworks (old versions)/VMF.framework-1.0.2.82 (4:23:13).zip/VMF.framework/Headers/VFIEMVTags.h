//
//  VFIEMVTags.h
//  VMF
//
//  Created by Randy Palermo on 10/25/10.
//

#import <Foundation/Foundation.h>

@class VFIEMVTags;

@interface VFIEMVTags : NSObject {
	NSMutableDictionary* emvTags;

}

-(void)clear;


@property (nonatomic, retain) NSMutableDictionary *emvTags;


@end
