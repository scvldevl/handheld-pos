//
//  VFIEMVCompletionData.h
//  VMF
//
//  Created by Randy Palermo on 9/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@class VFIEMVCompletionData;

@interface VFIEMVCompletionData : NSObject {
	NSMutableDictionary* emvTags;
	int cardRemovalResult;
	int writeToScriptResult;
	int validateMacResult;
}


-(void)clear;
-(id)init;

@property (nonatomic, retain) NSMutableDictionary* emvTags;
@property int cardRemovalResult;
@property int writeToScriptResult;
@property int validateMacResult;

@end
