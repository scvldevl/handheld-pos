//
//  VFIFinancialData.h
//  VMF
//
//  Created by Randy Palermo on 9/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VFICardData.h"
#import "VFIEncryptionData.h"
#import "VFIEMVAuthorization.h"
#import "VFIDataEntry.h"
#import "VFIEMVTags.h"


@class VFIFinancialData;

@interface VFIFinancialData : NSObject {

	VFICardData* cardData;
	VFIEncryptionData* encryptedData;
	NSMutableDictionary* emvTags;
	VFIEMVAuthorization *emvAuthorization;
	VFIDataEntry *cardholderEntries;
	NSMutableArray *additionalPrompts;
	NSMutableArray *additionalPromptResponses;
}


-(void)clear;


@property (nonatomic, retain) VFICardData* cardData;
@property (nonatomic, retain) VFIEncryptionData* encryptedData;
@property (nonatomic, retain) NSMutableDictionary* emvTags;
@property (nonatomic, retain) VFIEMVAuthorization *emvAuthorization;
@property (nonatomic, retain) VFIDataEntry *cardholderEntries;
@property (nonatomic, retain) NSMutableArray *additionalPrompts;
@property (nonatomic, retain) NSMutableArray *additionalPromptResponses;



@end
