//
//  VFIPayware.h
//  IDTech
//
//  Created by Randy Palermo on 5/4/10.
//  Copyright 2010 Rapadev, LLC. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import	<ExternalAccessory/ExternalAccessory.h>
#import "VFISoftwareVersion.h"
#import "VFIKeypadVersion.h"



@protocol VFIControlDelegate <NSObject>

@optional
- (void) controlLogEntry:(NSString*)logEntry withSeverity:(int)severity;
- (void) controlInitialized:(BOOL)isInitialized;


- (void) controlConnected:(BOOL)isConnected;
- (void) controlDataReceived:(NSData*)data;
- (void) controlDataSent:(NSData*)data;
@end

@class VFI_EADSessionController;

@interface VFIControl : NSObject <EAAccessoryDelegate, NSStreamDelegate,UIApplicationDelegate> {
	
	id <VFIControlDelegate> delegate;
	EAAccessory *_accessory;
	VFI_EADSessionController *_eaSessionController;
	VFISoftwareVersion *vfiSoftwareVersion;
	VFIKeypadVersion *vfiKeypadVersion;
}

-(id)init;
-(void) initDevice:(NSNotification *)notification;
-(void) initDevice;
-(void) initBridge;
-(void) initDeviceBackgroundAware:(UIApplication *)application;
-(void) closeDevice;
-(void) sendCommand:(NSString*)cmd;
-(void) sendCommandLRC:(NSString*)cmd;
-(void) simulatorMode:(BOOL)activate;
-(void) keypadEnabled:(BOOL)isEnabled;
-(void) hostPowerEnabled:(BOOL)isEnabled;
-(void) keypadBeepEnabled:(BOOL)isEnabled;
-(void) powerDown;
-(void) queryBatteryLevel;
-(void) querySoftwareVersion;
-(void) queryKeypadVersion;
-(void) hostPowerEnabled:(BOOL)isEnabled;
-(void) consoleEnabled:(BOOL)enable;
- (void)channelConnection:(NSString *)channelResponse;
-(void) setCommunicationID:(NSString *)commID;
-(id) initWithCommunicationID:(NSString *) commID;
-(NSString*) frameworkVersion;
-(NSString*) getLog;
-(NSString*) getLogFilename;
-(void) clearLog;
-(void) logEnabled:(BOOL)enable;
-(void) restartLoopDelay:(float)sec;
-(void) releaseOnDisconnect:(BOOL)release;
-(void)processReceivedData:(NSData*)data;

@property (retain) id delegate;
@property (nonatomic, readonly) NSString *controlName;
@property (nonatomic, readonly) NSString *controlManufacturer;
@property (nonatomic, readonly) NSString *controlModelNumber;
@property (nonatomic, readonly) NSString *controlSerialNumber;
@property (nonatomic, readonly) NSString *controlFirmwareRevision;
@property (nonatomic, readonly) NSString *controlHardwareRevision;
@property (nonatomic, readonly) NSString *softwareVersion;
@property (nonatomic, readonly) NSString *keypadVersion;
@property (readonly) int batteryLevel;
@property (readonly) BOOL controlSimulatorMode;
@property (readonly) BOOL controlConnected;
@property (readonly) BOOL connected;
@property (readonly) BOOL BTconnected;
@property (nonatomic, retain) VFISoftwareVersion *vfiSoftwareVersion;
@property (nonatomic, retain) VFIKeypadVersion *vfiKeypadVersion;


@property (readonly) BOOL initialized;




@end

