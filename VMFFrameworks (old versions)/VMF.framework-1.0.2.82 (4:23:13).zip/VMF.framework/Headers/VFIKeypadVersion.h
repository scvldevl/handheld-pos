//
//  VFIKeypadVersion.h
//  VMF
//
//  Created by Randy Palermo on 11/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface VFIKeypadVersion : NSObject {
	NSString *Processor;
	NSString *BootloaderMajor;
	NSString *BootloaderMinor;
	NSString *FirmwareMajor;
	NSString *FirmwareMinor;

	
	
}

-(void)clear;



@property (nonatomic, retain) NSString *Processor;
@property (nonatomic, retain) NSString *BootloaderMajor;
@property (nonatomic, retain) NSString *BootloaderMinor;
@property (nonatomic, retain) NSString *FirmwareMajor;
@property (nonatomic, retain) NSString *FirmwareMinor;


@end

